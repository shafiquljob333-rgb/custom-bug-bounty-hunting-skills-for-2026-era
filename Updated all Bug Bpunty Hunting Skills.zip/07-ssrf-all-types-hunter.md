---
name: ssrf-all-types-hunter
description: Deep SSRF research skill covering direct, blind, semi-blind, parser, redirect, DNS-rebinding, protocol-smuggling, cloud/internal and second-order SSRF with strict OOB and impact validation.
version: 2026.08
---

# SSRF — All-Types Hunter

## Mission
Find only server-side request forgery that crosses a real trust boundary. A URL being accepted, echoed, parsed, resolved, or causing latency is not enough. For blind SSRF, OOB confirmation is mandatory.

## Authorization Gate
- Confirm program, asset, endpoint/feature, credentials, test accounts and permitted callback infrastructure.
- Never probe arbitrary internal IP ranges, metadata services, or third-party systems unless the program explicitly authorizes the action.
- Prefer attacker-controlled canaries and benign internal-only test resources.

## Surface Discovery
Prioritize features that make the server fetch, resolve, render, import, preview, validate, transform or proxy a URL:
- URL preview/unfurl/link metadata
- image/file import from URL
- PDF/document generation and headless browsers
- webhooks/callbacks/integrations
- URL validators and health checks
- image resizing, thumbnailing, feed readers
- remote repository/package import
- OAuth/OIDC/SAML metadata retrieval
- cloud integrations and “test connection” functions
- GraphQL/REST URL fields, XML entities, template includes
- background jobs and asynchronous processors
- AI tools with fetch/browse capability

## SSRF Taxonomy
1. Direct response SSRF — attacker can read fetched response.
2. Blind SSRF — server fetches attacker-controlled URL but response is not reflected.
3. Semi-blind SSRF — status, size, timing or error differences expose partial information.
4. DNS-only SSRF — server performs attacker-observable DNS resolution.
5. Redirect SSRF — initial URL is allowed but redirect reaches a protected destination.
6. DNS rebinding — validation and fetch resolve differently.
7. Parser differential — validators and fetchers normalize URLs differently.
8. Protocol confusion — alternate schemes or parser fallbacks change the reachable surface.
9. SSRF through rendering engines — browser/PDF/image processors.
10. Second-order SSRF — attacker stores a URL; a later privileged worker fetches it.
11. SSRF through integrations/webhooks — backend service performs outbound requests.
12. SSRF-to-internal-admin/service abuse — reachable internal APIs.
13. SSRF-to-cloud identity exposure — metadata/identity endpoints where explicitly permitted.
14. SSRF-to-credential theft or secret exposure.
15. SSRF-to-RCE chains through internal management services.

## Hypothesis Method
For every URL sink record:
- source of URL
- validation point
- normalization/parser
- redirect policy
- DNS resolution behavior
- network egress context
- response visibility
- authentication context of the fetcher
- destination allow/deny logic
- whether another component performs the final fetch

## Differential Validation
Build a control matrix:

| Test | Expected | Observation | Meaning |
|---|---|---|---|
| benign public URL | fetch allowed | ... | baseline |
| unique canary URL | callback | ... | outbound fetch proof |
| invalid domain | rejection/error | ... | parser baseline |
| redirecting canary | callback | ... | redirect follow behavior |
| equivalent URL forms | same policy | ... | parser differential candidate |

## Blind SSRF Gate
Do not claim blind SSRF from:
- URL reflection
- generic error messages
- timing alone
- different application status codes alone
- DNS parsing behavior without a verified server-side resolution event

Require a unique OOB interaction that is attributable to the tested request. Use one unique canary per candidate when correlation is ambiguous.

## Safe Curl Pattern
```bash
curl -sk -D headers.txt -o body.txt \
  -H 'Accept: application/json' \
  -H 'X-Test-Case: ssrf-canary-001' \
  --data-urlencode 'url=https://UNIQUE-CANARY.example.test/' \
  'https://TARGET.example/api/feature'
```
Record timestamp, request ID, response status, redirects and OOB event ID.

## Parser / Redirect / Validation Questions
- Does validation occur before or after normalization?
- Are redirects revalidated at every hop?
- Does the validator resolve DNS once while the fetcher resolves again?
- Are userinfo, fragments, encoded separators, alternate IP representations or Unicode forms interpreted differently by layers?
- Does a proxy normalize differently from the application?
- Is an allowlist checking scheme/host while the final client follows redirects independently?

## Impact Ladder
Prefer real impact over theoretical reachability:
1. outbound request only
2. internal service reachability
3. readable sensitive internal data
4. privileged internal API action
5. cloud/workload credential exposure
6. credential-based privilege escalation
7. reproducible chain to RCE or tenant-wide compromise

## Chain Exploration
Every confirmed SSRF must trigger adjacent checks for:
- internal admin panels
- service-to-service APIs
- orchestration APIs
- CI/CD services
- secret/config endpoints
- cloud identity endpoints, only when authorized
- internal databases/caches with safe read-only canaries

## Kill Conditions
Kill the candidate when there is no verified outbound request, no meaningful boundary crossing, or the observed behavior is fully explained by client-side parsing.

## Final Evidence
Include exact request, exact response, callback/OOB evidence, affected server context, impact, and a minimal reproducible sequence. Never overclaim “internal access” when only DNS resolution was observed.
