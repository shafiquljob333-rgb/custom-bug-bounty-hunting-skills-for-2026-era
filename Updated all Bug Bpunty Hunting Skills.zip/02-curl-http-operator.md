---
name: curl-http-operator
description: Browserless curl-first HTTP research skill for authorized bug bounty and pentest work. Captures, normalizes, mutates, compares, and validates HTTP requests using curl, shell, jq, grep, and small local scripts. Optimized for reproducible raw requests, authenticated/unauthenticated differentials, state transitions, error analysis, and evidence collection without relying on a browser.
version: 1.0.0
---

# Curl HTTP Operator

## Mission

Operate at the HTTP protocol level when a browser is unavailable or intentionally avoided.

The unit of work is:

```text
REQUEST
 -> RESPONSE
 -> COMPARISON
 -> SECURITY INVARIANT
 -> PROOF
```

Never use curl merely to generate traffic. Every request belongs to a hypothesis.

## Safety Contract

- authorized targets only;
- use dedicated test accounts and objects;
- use non-destructive proofs whenever possible;
- avoid production load and excessive concurrency;
- respect program rate limits;
- do not expose or publish real credentials unnecessarily;
- sanitize sensitive evidence before final reporting unless the secret exposure itself is the finding.

## 0. Tooling Baseline

Recommended local tools:

```bash
curl
jq
grep
gawk
grep -P / perl when available
python3
sed
awk
openssl
sha256sum
```

Optional:

```bash
httpie
fzf
xargs
parallel
```

## 1. Canonical Request Capture

For every important request save:

```text
method
full URL
query string
request headers
cookies
authorization header
content type
body
response status
response headers
response body
redirect chain
timing
```

Prefer explicit files:

```bash
mkdir -p evidence/{requests,responses,meta}
```

### Verbose request

```bash
curl -sS -D evidence/responses/headers.txt \
  -o evidence/responses/body.txt \
  -w '\nSTATUS=%{http_code}\nTIME=%{time_total}\nSIZE=%{size_download}\n' \
  'https://TARGET/api/object/123' \
  -H 'Accept: application/json' \
  -H 'User-Agent: HighSeverityHunter/1.0'
```

When debugging transport:

```bash
curl -v 'https://TARGET/'
```

Do not rely on `-v` alone for the final evidence because it mixes transport and application output. Save clean headers/body separately.

## 2. Cookie and Session Handling

Use a cookie jar for dedicated test accounts:

```bash
curl -sS -c cookies-a.txt -b cookies-a.txt 'https://TARGET/login'
```

Never share session jars between attacker and victim test identities.

Keep explicit labels:

```text
COOKIE_A = attacker test account
COOKIE_B = victim test account
```

## 3. Auth Header Patterns

Cookie session:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'Cookie: session=REDACTED'
```

Bearer token:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'Authorization: Bearer REDACTED'
```

API key:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'X-API-Key: REDACTED'
```

Do not assume all accepted credentials are equivalent. Test the actual authorization boundary.

## 4. Baseline / Mutation / Differential Pattern

The most important curl pattern:

```text
BASELINE
  -> ONE CHANGE
  -> RESPONSE DIFFERENCE
  -> REPEAT
  -> CONTROL CASE
```

Never mutate many variables at once unless testing parser interactions intentionally.

Example:

```bash
curl -sS 'https://TARGET/api/orders/100' -H 'Cookie: session=COOKIE_A' > a.json
curl -sS 'https://TARGET/api/orders/101' -H 'Cookie: session=COOKIE_A' > b.json

diff -u a.json b.json
```

A difference is evidence of behavior, not proof of a vulnerability.

## 5. Method Differential Testing

Compare equivalent operations:

```text
GET vs POST
PUT vs PATCH
DELETE vs POST
HEAD vs GET
/api/v1 vs /api/v2
JSON vs form-urlencoded
single vs batch
```

Use this to detect inconsistent authorization/validation.

Example:

```bash
for method in GET POST PUT PATCH DELETE; do
  curl -sS -X "$method" 'https://TARGET/api/object/123' \
    -H 'Cookie: session=COOKIE_A' \
    -H 'Accept: application/json' \
    -o /tmp/body \
    -w "$method %{http_code} %{size_download}\n"
done
```

Only investigate methods that the application legitimately exposes or appears to recognize.

## 6. Header Differential Testing

Useful for identifying routing/auth assumptions:

```text
Authorization
Cookie
Origin
Referer
X-Requested-With
Content-Type
Accept
Accept-Language
User-Agent
```

Proxy metadata such as `X-Forwarded-For` must not be sprayed indiscriminately. Only test when the application appears to use client-IP metadata for a security decision and the program allows such testing.

## 7. Request Body Mutation

JSON:

```bash
curl -sS -X POST 'https://TARGET/api/update' \
  -H 'Content-Type: application/json' \
  -H 'Cookie: session=COOKIE_A' \
  --data '{
  "safe_field":"value"
}'
```

Form:

```bash
curl -sS -X POST 'https://TARGET/api/update' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Cookie: session=COOKIE_A' \
  --data 'safe_field=value'
```

XML:

```bash
curl -sS -X POST 'https://TARGET/api/import' \
  -H 'Content-Type: application/xml' \
  --data '<request><id>123</id></request>'
```

Multipart:

```bash
curl -sS -X POST 'https://TARGET/api/upload' \
  -H 'Cookie: session=COOKIE_A' \
  -F 'file=@test.txt' \
  -F 'description=test'
```

## 8. HTTP Response Fingerprinting

Capture a compact fingerprint:

```bash
curl -sS -D /tmp/h -o /tmp/b \
  -w 'code=%{http_code} type=%{content_type} bytes=%{size_download} time=%{time_total} redirect=%{url_effective}\n' \
  'https://TARGET/api/object/123'

printf '\n-- headers --\n'; sed -n '1,80p' /tmp/h
printf '\n-- body --\n'; sed -n '1,120p' /tmp/b
```

Useful comparison features:

- status code;
- Content-Type;
- Location;
- WWW-Authenticate;
- Set-Cookie;
- body length;
- stable JSON keys;
- object identifiers;
- error codes/messages;
- response timing.

Timing alone is rarely proof. Require repeatability and a meaningful side effect or data distinction.

## 9. JSON Differential Extraction

Use `jq` to compare structured responses:

```bash
jq -S . response.json > normalized.json
jq -r '.id, .ownerId, .role, .status' response.json
```

For array scope:

```bash
jq -r '.items[] | [.id,.ownerId,.status] | @tsv' response.json
```

For a suspected authorization differential:

```bash
jq -S '{status,ownerId,id,permissions,data}' a.json > a.norm
jq -S '{status,ownerId,id,permissions,data}' b.json > b.norm
diff -u a.norm b.norm
```

## 10. Unauthenticated Differential

Use three controls whenever possible:

```text
Unauth -> Object A
Auth A -> Object A
Unauth -> intentionally public object
```

A secure system may intentionally return a public representation while denying private fields.

The correct question is:

> Does the unauthenticated actor receive a protected capability or protected data that the application intends to reserve?

## 11. Two-Account Authorization Differential

The canonical matrix:

```text
A -> A's object       expected ALLOW
A -> B's object       expected DENY
B -> B's object       expected ALLOW
Unauth -> A's object  expected DENY when private
Low role -> privileged object expected DENY
Cross tenant -> same object ID expected DENY
```

Example:

```bash
curl -sS 'https://TARGET/api/orders/ORDER_A' -H 'Cookie: session=COOKIE_A' > a-a.json
curl -sS 'https://TARGET/api/orders/ORDER_B' -H 'Cookie: session=COOKIE_A' > a-b.json
curl -sS 'https://TARGET/api/orders/ORDER_B' -H 'Cookie: session=COOKIE_B' > b-b.json
```

The finding is the unauthorized differential, not merely the changed identifier.

## 12. Auth Boundary Checks

Test, when relevant:

```text
missing Cookie
expired Cookie
revoked token
wrong-account token
wrong-tenant token
old session after logout
old session after password reset
old token after role downgrade
```

Example:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'Cookie: session=REVOKED' \
  -o /tmp/r \
  -w '%{http_code} %{size_download}\n'
```

A successful response is not automatically a vulnerability. Confirm what authority remains and whether the security model requires revocation.

## 13. State-Machine Testing with curl

Represent a workflow as:

```text
S0 -> S1 -> S2 -> S3
```

For each transition capture the request and response.

Then test safe invalid transitions:

```text
S0 -> S2
S1 -> S3
S2 -> S1
S3 -> S2 after expiry/revocation
retry S2 -> S3
```

Examples:

```bash
curl -sS -X POST 'https://TARGET/api/checkout/complete' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"orderId":"TEST_ORDER"}'
```

Only use test-created orders/products/credits for financial flows unless the program explicitly permits otherwise.

## 14. Verification Gate Testing

Map:

```text
Gate -> evidence/token -> enforcement point -> protected action
```

Test one invariant at a time:

- remove verification evidence;
- replay evidence in the same authorized test account where permitted;
- use expired evidence;
- use evidence from test account A on test account B;
- call sibling protected endpoints directly.

The strongest evidence is a protected action succeeding without the required security condition.

## 15. Information Disclosure Validation

When an endpoint exposes interesting data, classify the data first.

Use:

```bash
jq 'keys' response.json
jq 'del(.publicField1,.publicField2)' response.json
```

Ask:

- Is it intentionally public?
- Is it documented?
- Is it already delivered to normal users?
- Is it a public client identifier?
- Is it a secret credential?
- Does it unlock another protected action?

Never escalate a report solely because a value “looks internal.”

## 16. Redirect and SSRF Evidence

Redirect:

```bash
curl -sS -D - -o /dev/null 'https://TARGET/login?next=https%3A%2F%2Fexample.com'
```

SSRF discovery should stay bounded and safe. Prefer a collaborator/callback service supplied by the authorized assessment or a harmless endpoint you control. Do not probe internal infrastructure broadly.

Proof hierarchy:

```text
URL accepted
 < server makes outbound request
 < callback proves target server made request
 < response/body proves internal data read
 < protected internal capability obtained
```

A callback is stronger than mere URL acceptance, and actual protected-data access is stronger than a blind callback.

## 17. Injection Testing Pattern

For SQL/NoSQL/template/command-like inputs, follow:

```text
baseline
 -> harmless syntax mutation
 -> error differential
 -> boolean differential
 -> timing differential if justified
 -> bounded proof
```

Do not perform destructive DB writes, destructive commands, or high-volume extraction on production systems.

Timing tests must use small, repeatable delays and controls.

### Minimal timing collection

```bash
for i in 1 2 3 4 5; do
  curl -sS -o /dev/null -w '%{time_total}\n' \
    'https://TARGET/api/search?q=SAFE_TEST'
done
```

Compare against an equivalent control request before attributing timing to injection.

## 18. Safe Race Testing

Races require evidence of an invariant violation, not just concurrency.

Minimum proof set:

```text
number of concurrent requests
expected successes
actual successes
state before
state after
invariant violated
```

Use the smallest practical concurrency, test objects, and bounded bursts.

Example pattern:

```bash
seq 1 3 | xargs -n1 -P3 -I{} curl -sS -X POST \
  'https://TARGET/api/test-action' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"testObjectId":"OBJ"}'
```

Three requests are illustrative, not a mandate. Increase only when the program permits it and the signal cannot be established otherwise.

## 19. Reproducibility Harness

Create a deterministic script:

```bash
#!/usr/bin/env bash
set -euo pipefail
BASE='https://TARGET'
COOKIE='REDACTED'

curl -sS "$BASE/api/test-object/OBJ" \
  -H "Cookie: session=$COOKIE" \
  -H 'Accept: application/json' \
  -D headers.txt -o body.json

printf 'HTTP body hash: '
sha256sum body.json
```

A stranger should be able to understand the exact request sequence from the saved script.

## 20. Evidence Package

For each candidate save:

```text
00-scope.txt
01-baseline.request
01-baseline.response.headers
01-baseline.response.body
02-mutated.request
02-mutated.response.headers
02-mutated.response.body
03-control.request
03-control.response
04-analysis.md
05-impact.md
```

Do not store reusable real credentials in the final package.

## 21. Curl Anti-Patterns

Do not:

- blindly fuzz thousands of parameters;
- treat 200 as vulnerability proof;
- infer auth bypass from a different error page only;
- trust a client-supplied role/price/verification flag without testing the protected effect;
- rotate spoofed IP headers unless the IP is actually a relevant security control;
- claim SSRF from a parser accepting `http://`;
- claim SQLi from an isolated 500 error;
- claim IDOR from an accessible object that is intentionally public;
- use timing differences without repeatability/control;
- report a request that cannot be reproduced.

## 22. Final Handoff

When curl establishes a candidate, provide:

```yaml
exact_request:
exact_response:
control_request:
control_response:
security_invariant:
unauthorized_capability:
concrete_impact:
repro_steps:
design_intent_status:
novelty_status:
```

Then route to `06-validation-triage-novelty-reporting`.
