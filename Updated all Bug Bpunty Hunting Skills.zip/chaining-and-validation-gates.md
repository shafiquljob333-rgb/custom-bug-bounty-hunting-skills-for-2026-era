# Chaining & Validation Gates

A finding doesn't become a report just because it's real. It becomes a report once it survives an honest attempt to kill it, and ideally once it's been chained to the highest impact it can legitimately support.

## The one question that matters

> **Can an attacker do this right now, against a real user who took no unusual action, and does it cause real, demonstrable harm — stolen money or credentials, leaked PII, account takeover, or code execution?**

If the honest answer is no, stop working on the writeup and either keep testing (to build the missing proof) or drop it entirely.

## Kill these on sight

| Pattern | Why it's dead |
|---|---|
| "Could theoretically allow..." | Not exploitable = not a bug yet |
| "An attacker with conditions X, Y, and Z could..." | Too many preconditions to be realistic |
| Technically wrong, but no reachable impact | Wrong ≠ exploitable |
| Bug in genuinely dead/unreachable code | Not reachable = not a bug |
| Open redirect / self-XSS / CORS wildcard reported alone | Each becomes valid *only* once chained (see table below) |
| SSRF confirmed via DNS callback only | Need actual data return or internal access, not just proof the request left the server |

## The A → B → C chaining method

When you confirm bug A, don't stop — deliberately hunt for a sibling bug B on the same feature/module, and see if A + B compose into something bigger. Chains consistently pay several times more than the same bugs reported separately, because they demonstrate real end-to-end impact instead of a single broken check.

**Protocol:**
1. **Confirm A** with an actual request/response.
2. **Map siblings** — every endpoint in the same controller/module/API group.
3. **Test siblings** for the same bug class, and for different classes that might combine with A.
4. **Chain** — if a sibling has a different, compatible bug class, try combining them into one exploit path.
5. **Quantify** — "affects N users," "exposes $X," "N records readable."
6. **Report once**, as a single chain, not as separate low-severity tickets.

**Known signal chains** (bug A found → go look for B):

| Bug A (signal) | Hunt for B | Escalates to |
|---|---|---|
| IDOR (read-only) | PUT/DELETE on the same endpoint | Full read+write compromise of another user's data |
| SSRF (any) | Cloud metadata endpoint reachable | Credential exposure → further access (only pursue with explicit authorization) |
| Stored XSS | Is the session cookie missing `HttpOnly`? | Session hijack → account takeover |
| Open redirect | Does OAuth `redirect_uri` accept your domain? | Authorization-code theft → account takeover |
| Public/listable storage bucket | Enumerate JS bundles inside it | Hardcoded credentials → further chain |
| Missing/weak rate limit | OTP or password brute force | Account takeover |
| GraphQL introspection enabled | Missing field-level auth on a resolver | Mass PII exposure |
| Debug endpoint exposed | Leaked environment variables | Credential exposure → infrastructure access |
| CORS reflects arbitrary origin | Does it also allow credentials? | Credentialed cross-origin data theft |
| Host header injection accepted | Does it poison the password-reset link? | Account takeover via reset-link hijack |

## Findings that are only valid *with* a chain

| Low-severity alone | Chain required | Becomes |
|---|---|---|
| Open redirect | OAuth `redirect_uri` code theft | Account takeover |
| CORS wildcard | Credentialed exfiltration PoC | Data theft |
| CSRF | Sensitive state-changing action | Account takeover |
| No rate limit | OTP brute force demonstrated | Account takeover |
| Self-XSS | Realistic delivery vector (login CSRF, clickjacking) | Stored XSS on a real victim |
| Clickjacking | Sensitive action + working PoC | Account action performed without consent |
| SSRF (DNS-only) | Internal access or data return proven | Internal network access |

## The 7-question gate — run before writing any report

All seven must be **yes**. Any **no** means stop and either fix it or drop the finding.

1. **Can I exploit this right now with a real PoC?** Write the exact request. If you can't, it isn't ready.
2. **Does it affect a real user who took no unusual action?** No "the victim would need to..." with five preconditions.
3. **Is the impact concrete?** Money, PII, account takeover, or code execution — not "technically possible."
4. **Is this in scope**, per the program's actual scope document, checked today?
5. **Have I checked for duplicates** — searched public disclosures/Hacktivity, checked recent changelog entries?
6. **Is this not on the "generally not accepted alone" list** below, unless it's chained?
7. **Would a tired triager reading this at 5pm on a Friday say "yes, that's real"?**

## Findings that are almost never accepted alone

Missing security headers (CSP/HSTS) without a working exploit, missing SPF/DKIM/DMARC, GraphQL introspection alone, version/banner disclosure without a working CVE exploit, clickjacking on a non-sensitive page, tabnabbing, self-XSS without a delivery vector, open redirect alone, SSRF with DNS-only callback, host header injection alone, missing `HttpOnly`/`Secure` flags alone, no rate limit on a non-critical form, broken external links, autocomplete enabled on a password field.

These aren't "never valid" — they're "never valid *alone*." Check the chaining table above before discarding one.

## Pre-submission checklist

- [ ] I verified this asset is explicitly in scope, checked against today's scope document
- [ ] I searched for duplicates (public disclosures, changelog, recent fixes)
- [ ] Steps to reproduce are numbered, exact, and copy-paste runnable
- [ ] I have evidence — screenshot, video, or raw request/response — not just a description
- [ ] Title states vulnerability class + location + impact in one line
- [ ] Impact is described as what actually happened in my test, with worst-case impact framed as a reasoned inference, not an unproven claim
- [ ] Severity is justified by impact, not by how technically interesting the bug is
- [ ] I used two distinct accounts/sessions where the bug requires it
- [ ] Tone is neutral and professional — no blame language, no exaggeration
- [ ] Any real user data captured as evidence is redacted before it goes in the report
