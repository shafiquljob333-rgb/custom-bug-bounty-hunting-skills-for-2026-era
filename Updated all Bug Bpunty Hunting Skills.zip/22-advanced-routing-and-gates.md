---
name: advanced-routing-and-gates
description: Cross-skill routing layer for specialist selection, evidence gates, duplicate resistance and final decision semantics.
version: 2026.08
---

# Advanced Skill Router & Evidence Gates

## Route by Surface
- URL fetch/import/render → SSRF
- unobservable browser/SQL effect → Blind/OOB
- financial/one-time/state checks → Race
- authentication/recovery/identity linking → ATO
- execution sink → RCE
- proxy/edge/backend parser mismatch → Request Smuggling
- blocked payload reaches vulnerable origin → WAF Bypass
- unknown assets/endpoints/JS/params → Recon Master
- exceptional impact candidates → Critical Finder
- multiple confirmed primitives → Chaining Engine
- CDN/cache behavior → Cache Deception/Poisoning
- implicit rules → Assumption Breaker
- object/tenant/role checks → IDOR/Access Control
- sensitive artifacts/data → Information Disclosure
- ambiguous/high-level decision-making → Elite Attacker Thinker

## Candidate State Machine
```text
DISCOVERED
  ↓
HYPOTHESIS
  ↓
CANDIDATE
  ↓
REPRODUCED
  ↓
SECURITY-BOUNDARY PROVEN
  ↓
IMPACT PROVEN
  ↓
CHAIN REVIEW
  ↓
NOVELTY / DUPLICATE REVIEW
  ↓
FINAL VALIDATION
  ↓
REPORT
```

## No-Skip Gates
A finding cannot jump directly from “interesting” to “report.”

### Scope Gate
Asset, endpoint and technique are authorized.

### Intent Gate
The behavior is inconsistent with intended security/business rules.

### Proof Gate
Exact request + exact relevant response/state evidence.

### Impact Gate
Attacker capability or victim harm is concretely demonstrated.

### Novelty Gate
Search historical knowledge and systemic patterns. Identify whether this is a duplicate, regression, materially new variant or independently valuable finding.

### Safety Gate
Stop after sufficient evidence. Do not broaden into harmful exploitation merely to increase severity.

## False-Positive Repair Loop
```text
FALSE POSITIVE
   ↓
WHY DID THE HYPOTHESIS LOOK PLAUSIBLE?
   ↓
WHICH CONTROL DISPROVED IT?
   ↓
UPDATE ASSUMPTION / MODEL
   ↓
FIND ADJACENT UNTESTED VARIANT
   ↓
RE-HUNT
```

## Final Decision
Only classify as valid when all mandatory evidence gates are satisfied. If not, retain as rejected candidate with the reason, rather than forcing a report.
