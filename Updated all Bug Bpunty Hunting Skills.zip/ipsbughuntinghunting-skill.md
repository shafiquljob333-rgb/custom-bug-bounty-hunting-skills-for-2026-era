---
name: ips-cidr-bug-hunting-engine
title: "IP / CIDR Bug Hunting — External Infrastructure & Attack-Surface Intelligence"
version: "1.0.0"
category: "Recon / Infrastructure / Chaining / Severity"
access: "Authorized security testing only"
---

# IP / CIDR Bug Hunting — External Infrastructure & Attack-Surface Intelligence

## 0. Mission

This skill is the specialist engine for finding **real, reportable security vulnerabilities on explicitly authorized IP addresses, CIDR ranges, ASNs, owned infrastructure, and externally reachable services**.

Its purpose is not merely to enumerate ports. Its purpose is to transform:

```text
AUTHORIZED CIDR / IP SPACE
        ↓
OWNERSHIP + SCOPE CONFIRMATION
        ↓
IP / HOST / SERVICE INVENTORY
        ↓
HTTP / TLS / DNS / PROTOCOL MAPPING
        ↓
HIDDEN VIRTUAL HOSTS + ALTERNATE SERVICES
        ↓
SECURITY-INVARIANT HYPOTHESES
        ↓
LOW/MEDIUM FINDING DISCOVERY
        ↓
CHAIN ANALYSIS
        ↓
HIGH / CRITICAL IMPACT
        ↓
STRICT VALIDATION
        ↓
NOVELTY / DUPLICATE CHECK
        ↓
TRIAGER-GRADE REPORT
```

The objective is:

> Find a security-boundary violation on authorized infrastructure and prove the highest real impact that can be safely demonstrated.

This follows the suite's existing impact-first and evidence-first doctrine: scope before testing, real harm over theory, and aggressive false-positive/duplicate rejection. fileciteturn4file0L12-L42

---

# 1. HARD AUTHORIZATION GATE

Before active IP/CIDR testing, establish:

```text
PROGRAM / ENGAGEMENT
        ↓
AUTHORIZED ORGANIZATION
        ↓
AUTHORIZED CIDR / IP / ASN
        ↓
AUTHORIZED TEST TYPE
        ↓
RATE / AUTOMATION RESTRICTIONS
        ↓
THIRD-PARTY LIMITATIONS
```

Never infer authorization from ASN association, WHOIS alone, reverse DNS, a TLS certificate, a brand logo, shared hosting, CDN ownership, or a subdomain that happens to resolve to an IP.

If ownership or authorization is ambiguous:

```text
STOP ACTIVE TESTING
→ mark ASSET = UNCONFIRMED
→ passive correlation only
→ return to scope clarification
```

---

# 2. PRIME DIRECTIVE — CIDR IS ONLY THE BOUNDARY

Model the infrastructure as:

```text
CIDR
 ├── IPs
 │    ├── DNS names
 │    ├── reverse DNS
 │    ├── certificates
 │    ├── services
 │    ├── ports
 │    └── protocols
 ├── shared infrastructure
 ├── cloud assets
 ├── load balancers
 ├── gateways
 ├── management planes
 ├── APIs
 ├── internal-style services accidentally exposed
 └── legacy / forgotten hosts
```

An open port is not automatically a vulnerability.
A live IP is not automatically a finding.
A version string is not automatically a vulnerability.

Ask:

> What unexpected capability does this exposed infrastructure provide to an attacker?

---

# 3. THREAT MODEL

For every asset evaluate:

### Confidentiality
Can the attacker read:
- credentials
- PII
- tenant data
- source code
- backups
- database contents
- secrets
- internal service responses
- logs
- administrative information

### Integrity
Can the attacker:
- modify configuration
- write files
- alter records
- create accounts
- change permissions
- publish content
- alter CI/CD state
- poison caches
- inject commands
- affect another tenant

### Availability
Can the attacker cause meaningful application or operational disruption?

Do not conduct destructive availability tests unless explicitly authorized.

---

# 4. IP / CIDR ASSET GRAPH

Maintain a structured record:

```text
asset_id
ip
cidr
reverse_dns
forward_dns
hostname
virtual_hosts
asn
provider
open_ports
service
protocol
tls_certificate
certificate_names
http_status
http_title
server_header
technology
auth_required
admin_indicator
api_indicator
cloud_indicator
risk_level
scope_status
last_seen
```

Track lifecycle states:

```text
DISCOVERED
→ RESOLVED
→ LIVE
→ SERVICE-IDENTIFIED
→ INTERESTING
→ HYPOTHESIS
→ CONFIRMED
→ VALIDATED
```

Also track:

```text
REJECTED
DUPLICATE
OUT-OF-SCOPE
```

---

# 5. PHASE 1 — CIDR NORMALIZATION

Never silently broaden supplied ranges.

For an authorized lab/scope:

```bash
python3 - <<'PY'
import ipaddress
cidr = "192.0.2.0/24"
for ip in ipaddress.ip_network(cidr, strict=False):
    print(ip)
PY
```

Store the normalized IP inventory so every later action maps back to the exact authorized range.

---

# 6. PHASE 2 — PASSIVE INFRASTRUCTURE CORRELATION

Before active probing, correlate:

- reverse DNS
- DNS records
- TLS certificate names
- public docs
- known organization hostnames
- ASN
- cloud/provider clues
- historical hostnames
- public service naming patterns

Passive evidence is a discovery input, not proof of ownership or vulnerability.

---

# 7. PHASE 3 — REVERSE DNS

Useful signals:

```text
mail
vpn
api
admin
dev
staging
internal
legacy
gateway
proxy
monitoring
metrics
git
ci
registry
db
backup
```

Example:

```bash
dig -x 192.0.2.10 +short
```

Batch:

```bash
while read -r ip; do
  printf "%-16s " "$ip"
  dig -x "$ip" +short | tr '\n' ' '
  echo
done < ips.txt
```

An internal-looking PTR record is only a lead.

---

# 8. PHASE 4 — LIVE HOST DISCOVERY

Use low-impact discovery first.

Track separately:

```text
ICMP STATUS
TCP STATUS
UDP STATUS (only when authorized/necessary)
APPLICATION STATUS
```

A host can block ICMP while exposing HTTPS.
Do not assume ping failure means the host is dead.

Do not flood the range.

---

# 9. PHASE 5 — SERVICE DISCOVERY

Goal:

```text
IP
→ Port
→ Protocol
→ Service
→ Version / Behavior
→ Security Boundary
```

Common signals include:

```text
22    SSH
25    SMTP
53    DNS
80    HTTP
443   HTTPS
389   LDAP
445   SMB
5432  PostgreSQL
3306  MySQL
6379  Redis
9200  Elasticsearch
8080  HTTP-alt
8443  HTTPS-alt
9090  Monitoring
3000  Web application
5000  Developer/API service
```

The port number itself is never the finding.

---

# 10. CURL-FIRST SERVICE CONFIRMATION

Prefer exact HTTP evidence when HTTP-like services appear.

```bash
curl -skI https://192.0.2.10/
```

Host override:

```bash
curl -sk \
  -H 'Host: example.com' \
  https://192.0.2.10/
```

Capture complete response:

```bash
curl -sk \
  -D headers.txt \
  -o body.html \
  https://192.0.2.10/
```

Track:
- status
- headers
- redirects
- server
- content type
- cache behavior
- authentication indicators

---

# 11. IP-BASED HTTP HOSTING

A major IP-hunting opportunity is identifying applications selected by the HTTP Host header.

```bash
for host in app.example.com api.example.com admin.example.com; do
  echo "===== $host ====="
  curl -sk \
    -H "Host: $host" \
    -o /dev/null \
    -w '%{http_code} %{size_download} %{time_total}\n' \
    https://192.0.2.10/
done
```

Compare:
- status
- length
- title
- headers
- redirects
- authentication
- cache behavior

The purpose is discovering:
- hidden vhosts
- staging
- legacy applications
- management planes
- alternate APIs
- authorization inconsistencies

A Host-based response difference alone is not a vulnerability.

---

# 12. TLS CERTIFICATE INTELLIGENCE

Inspect SAN/CN/issuer/chain/expiry.

```bash
openssl s_client \
  -connect 192.0.2.10:443 \
  -servername example.com </dev/null 2>/dev/null |
  openssl x509 -noout -text
```

Certificate names can reveal:
- API hosts
- staging
- old hosts
- alternate domains
- internal-style names

Certificate evidence is a discovery clue, not automatic scope or impact evidence.

---

# 13. HIDDEN VIRTUAL HOST HUNTING

For all authorized hostname candidates, create a differential matrix:

```text
hostname
HTTP status
response length
title
Location
Set-Cookie
server
cache headers
TLS behavior
auth behavior
```

Prioritize differences that cross security boundaries.

Examples:
- public frontend vs admin frontend
- production vs staging
- API v1 vs API v2
- authenticated vs anonymous behavior

---

# 14. IP-ONLY APPLICATIONS

Test carefully:

```bash
curl -sk https://192.0.2.10/
curl -sk -H 'Host: 192.0.2.10' https://192.0.2.10/
```

Ask:

> Does the IP route expose capabilities unavailable through the intended hostname?

Useful findings require a real security consequence.

---

# 15. MANAGEMENT-PLANE HUNT

Where discovery indicates it is relevant, investigate paths such as:

```text
/admin
/manager
/console
/actuator
/metrics
/debug
/internal
/monitoring
/health
/status
/api-docs
/swagger
/openapi.json
/graphql
/graphiql
```

Do not brute-force every endpoint without evidence.

Strong reportable condition:

```text
Management surface
+
missing/weak authorization
+
meaningful privileged capability
```

---

# 16. SECURITY INVARIANTS

For every exposed service ask:

### Authentication invariant
Protected administrative functionality must require the intended authentication.

### Authorization invariant
A low-privilege actor must not obtain privileged capabilities.

### Tenant invariant
One tenant must not access another tenant.

### Network-boundary invariant
Internal-only services must not be reachable from the Internet without intended controls.

### Data invariant
Public endpoints must not return private system data.

### Protocol invariant
Multiple infrastructure layers must interpret requests consistently.

### Legacy invariant
Old/debug interfaces must not accidentally retain production privileges.

---

# 17. SERVICE-BASED ROUTING

## HTTP
Route toward:
- 02 Curl HTTP Operator
- 01 MasterJS Analyzer
- 04 Unauthenticated Hunter
- 05 Authenticated Hunter
- 19 IDOR / Access Control
- 07 SSRF
- 17 Cache
- 12 Request Smuggling
- 13 WAF
- 03 Business Logic

## DNS
Investigate authorized DNS exposures such as:
- unintended zone transfer
- internal host disclosure
- stale records
- dangling references

## SMTP
Investigate:
- unintended sensitive behavior
- relay boundaries where permitted
- authentication weaknesses
- meaningful information disclosure

## LDAP
Investigate:
- unauthorized anonymous read
- directory exposure
- access-control failures

## Databases / data services
Prioritize:
- unintended public exposure
- missing authentication
- unauthorized reads/writes
- cross-tenant data access

Use minimal non-destructive proof.

---

# 18. HTTP STATUS DIFFERENTIALS

Useful signals:

```text
401 → 200
403 → 200
404 → 200
302 → privileged panel
500 → internal exception
Host A → response A
Host B → response B
```

These are only signals.

The question is:

> What security capability changed?

---

# 19. LEGACY SERVICE HUNTING

Compare authorized versions and known host families:

```text
/api/
/api/v1/
/api/v2/
legacy.example.com
old.example.com
staging.example.com
dev.example.com
```

Look for:
- weaker authentication
- missing authorization
- old business logic
- parser differences
- weaker tenant isolation

Do not assume old = vulnerable.

---

# 20. NON-LIVE / HISTORICAL IP INTELLIGENCE

A currently dead host can still reveal:
- historical API routes
- old hostnames
- CNAME relationships
- old application architecture
- forgotten environments
- legacy product paths

Track it as:

```text
HISTORICAL LEAD
```

not as a live vulnerability.

If ownership later becomes ambiguous, stop active testing.

---

# 21. IPv6 DIFFERENTIAL

Where IPv6 is explicitly authorized:

Inventory:
- AAAA records
- IPv6 hosts
- services
- virtual hosts
- access-control differences
- proxy differences

Compare IPv4 vs IPv6 security controls.

Potentially valuable:

```text
IPv4: 403
IPv6: 200
```

But only if the capability is sensitive and the difference actually crosses a security boundary.

Do not assume IPv4 authorization implies IPv6 authorization.

---

# 22. ORIGIN EXPOSURE

For CDN-fronted applications, determine whether a discovered origin IP bypasses intended edge controls.

Potential chain:

```text
Origin exposed
→ WAF / auth bypass
→ protected endpoint
→ real impact
```

“Origin IP discovered” alone is not the finding.

---

# 23. EDGE / ORIGIN DIFFERENTIAL

Where explicitly authorized, compare:

```text
public hostname
vs
origin IP
vs
alternate hostname
vs
alternate port
```

Evaluate:
- WAF
- authentication
- rate limiting
- routing
- caching
- debug behavior

Strong proof:

```text
same resource
+
same test account
+
different route
+
different security outcome
```

---

# 24. RATE-LIMIT DIFFERENTIAL

Use minimal controlled testing.

Compare whether:
- hostname and IP have different limits
- edge and origin enforce differently
- IPv4/IPv6 differ
- alternate ports bypass controls

Do not conduct unnecessary request floods.

A rate-limit difference is reportable only when it leads to meaningful abuse such as a demonstrated authentication, OTP, transaction, or account-security bypass.

---

# 25. HIGH-VALUE INFRASTRUCTURE SIGNALS

### Tier 1
- exposed management interface with unauthorized capability
- exposed sensitive internal data
- exposed usable credentials/secrets
- origin bypass that removes a meaningful security control
- cross-tenant compromise
- exploitable RCE
- meaningful authentication bypass
- SSRF into sensitive internal services
- exploitable request smuggling
- ATO chain

### Tier 2
- significant privilege escalation
- sensitive disclosure
- cache compromise
- WAF bypass leading to a backend vulnerability
- dangerous unauthenticated service
- important authorization differential

### Tier 3
- generic banners
- harmless version strings
- intentionally public services
- missing hardening headers
- low-impact configuration issues

Spend most active time on Tier 1.

---

# 26. SEVERITY

## LOW
Examples:
- minor disclosure
- harmless metadata
- low-impact configuration

## MEDIUM
Examples:
- meaningful but limited data exposure
- constrained authorization failure
- limited workflow abuse

## HIGH
Examples:
- broad sensitive-data exposure
- significant privilege escalation
- important account-control pathway
- internal administrative access
- serious origin bypass
- high-impact SSRF

## CRITICAL
Examples:
- full account takeover
- remote code execution
- broad cross-tenant compromise
- major credential compromise
- administrator compromise
- severe financial compromise
- control-plane/cloud compromise

Severity depends on demonstrated impact, not the port or service label.

---

# 27. LOW/MEDIUM → HIGH/CRITICAL CHAINING

Every meaningful Low/Medium candidate gets a mandatory question:

> What does this unlock?

Build connectors only from proven capabilities.

### INFO → IDOR

```text
IP disclosure
→ API hostname
→ object ID
→ IDOR
→ private data
```

### ORIGIN → WAF BYPASS

```text
origin exposure
→ edge bypass
→ privileged endpoint
→ privilege escalation
```

### INFO → SSRF

```text
internal hostname
→ public fetcher
→ SSRF
→ internal service
→ credential/data access
```

### PROXY DIFFERENTIAL → SMUGGLING

```text
proxy stack
→ parser differential
→ request smuggling
→ cache/auth impact
```

### AUTH → ATO

```text
exposed recovery endpoint
→ verification weakness
→ session control
→ account takeover
```

### CACHE → XSS/ATO

```text
cache-key flaw
→ attacker-controlled response cached
→ victim receives poisoned content
→ XSS / credential-impact path
```

Never treat “could chain” as proven chaining.

---

# 28. CHAINING RULE

Only report a chain when:

```text
A proven
→ B proven
→ C proven
→ final impact proven
```

Do not write:

```text
Low A
+ hypothetical B
= Critical
```

The complete chain's validated impact determines the severity assessment.

The existing suite explicitly emphasizes A-to-B chaining while rejecting speculative “could chain” claims unless the chain is actually built. fileciteturn4file0L21-L32

---

# 29. FALSE-POSITIVE TRAPS

Do not misclassify:

### Open port
Not automatically a vulnerability.

### Service banner
Not automatically a vulnerability.

### Internal-looking hostname
Not automatically sensitive.

### 200 response
Not automatically authorized.

### Certificate mismatch
Not automatically exploitable.

### Origin IP exposure
Not automatically a security issue.

### WAF bypass
Not automatically a reportable issue.

### Old software
Not automatically vulnerable without exploitable context.

### Public API
Not automatically private.

### Legacy host
Not automatically vulnerable.

---

# 30. DIFFERENTIAL MATRIX

For relevant findings create a matrix:

| Route | Auth | Host/IP | Expected | Actual |
|---|---|---|---|---|
| /admin | none | public | 401/403 | ? |
| /admin | user | origin | 403 | ? |
| /api/object/A | user A | public | A-owned | ? |
| /api/object/B | user A | alternate route | deny | ? |

A strong proof demonstrates an explicit security-boundary differential.

---

# 31. EVIDENCE LEDGER

Maintain:

```text
candidate_id
asset
ip
hostname
port
service
hypothesis
status
evidence
impact
chain
scope
duplicate_status
confidence
next_action
```

Candidate state machine:

```text
LEAD
→ HYPOTHESIS
→ REPRODUCED
→ SECURITY BOUNDARY PROVEN
→ IMPACT PROVEN
→ CHAIN REVIEWED
→ NOVELTY CHECKED
→ VALIDATED
→ REPORTABLE
```

Also:

```text
REJECTED
DUPLICATE
OUT-OF-SCOPE
```

---

# 32. RECON TOOLING PRINCIPLES

Tools are execution layers, not the methodology.

Potential authorized tooling:

```text
dig
host
openssl
curl
httpx
nmap
naabu
dnsx
puredns
subfinder
amass
```

Every tool action should answer a hypothesis.

Avoid “run every scanner against every address” behavior.

---

# 33. CURL-FIRST TEST KIT

Headers:

```bash
curl -skI https://192.0.2.10/
```

Host override:

```bash
curl -sk \
  -H 'Host: app.example.com' \
  https://192.0.2.10/
```

Capture:

```bash
curl -sk \
  -D response.headers \
  -o response.body \
  https://192.0.2.10/
```

Compare fingerprints:

```bash
curl -sk \
  -o /tmp/a \
  -w '%{http_code} %{size_download} %{time_total}\n' \
  https://192.0.2.10/

curl -sk \
  -H 'Host: app.example.com' \
  -o /tmp/b \
  -w '%{http_code} %{size_download} %{time_total}\n' \
  https://192.0.2.10/
```

Use a control and repeat when timing or size differences matter.

---

# 34. “WHAT NEXT?” DECISION TREE

```text
AUTHORIZED CIDR?
   ↓ YES
BUILD IP INVENTORY
   ↓
LIVE HOST?
   ├── NO → PASSIVE / HISTORICAL CORRELATION
   └── YES
        ↓
SERVICE?
        ↓
HTTP?
   ├── YES → CURL
   │          ↓
   │       VHOST DIFFERENTIAL
   │          ↓
   │       AUTH DIFFERENTIAL
   │          ↓
   │       IDOR / SSRF / CACHE / WAF / SMUGGLING / ATO
   │
   └── NO → SERVICE-SPECIFIC ROUTE
        ↓
AUTHENTICATION?
   ├── NO → UNAUTH HUNT
   └── YES → AUTH HUNT
        ↓
SENSITIVE CAPABILITY?
   ├── NO → LOWER PRIORITY
   └── YES
        ↓
CHAIN?
   ├── YES → CHAIN ENGINE
   └── NO
        ↓
VALIDATION
```

---

# 35. WHEN TO CALL THE OTHER SKILLS

### 02 Curl HTTP Operator
HTTP or API request control is needed.

### 01 MasterJS Analyzer
The exposed web application ships JavaScript, source maps, client-side routes or parameters.

### 04 Unauthenticated Hunter
Public reachability suggests missing route authentication or pre-auth exposure.

### 05 Authenticated Hunter
Valid accounts are available and authorization must be tested.

### 07 SSRF
A server-side fetch/import/preview/render capability is identified.

### 09 Race Condition
Concurrency or stale-state behavior is observed.

### 10 ATO
Identity, recovery, session or OAuth state is involved.

### 11 RCE
Server-side execution is suspected.

### 12 Request Smuggling
Multiple HTTP layers show parser-differential signals.

### 13 WAF Bypass
Edge filtering differs from backend behavior and a real backend bug is suspected.

### 17 Cache
Cache behavior impacts another user/context.

### 19 IDOR / Access Control
Object/tenant references appear in the discovered services.

### 20 Information Disclosure
Sensitive information is exposed.

### 16 Bug Chaining Engine
A validated Low/Medium finding may be a bridge to larger impact.

### 06 Validation / Triage
Always before final reporting.

---

# 36. STOP CONDITIONS

Stop the branch when:
- authorization is missing/ambiguous
- ownership is unconfirmed
- behavior is theoretical only
- no security boundary is crossed
- data is already public
- behavior is intentional/documented
- no meaningful impact exists
- duplicate is confirmed
- evidence is scanner-only
- the test would violate engagement restrictions

---

# 37. COMPLETION CRITERIA

IP/CIDR hunting is complete only when:

- authorized ranges are normalized
- ownership/scope is verified
- major live hosts are inventoried
- high-value services are identified
- major HTTP services are tested
- virtual-host differentials are evaluated
- high-value management interfaces are assessed
- relevant edge/origin differences are assessed
- IPv6 is covered when explicitly authorized
- legacy/historical clues are incorporated
- serious candidates are validated
- Low/Medium candidates were checked for chaining
- duplicate/novelty analysis is complete
- false positives are rejected
- all final findings contain exact evidence

---

# 38. REPORT FORMAT

Title:

`[Vulnerability] on [IP/hostname/service] allows [concrete impact]`

Include:

```text
Asset
IP
Hostname
Port
Protocol
Authentication state
Prerequisites
Exact request
Exact response
Observed behavior
Security invariant violated
Concrete impact
Validated chain
Severity
Reproduction steps
Remediation direction
Novelty / duplicate assessment
```

Never report only:

```text
open port
old version
banner
internal hostname
```

without a demonstrated security consequence.

---

# 39. FINAL DIRECTIVE

Operate like an infrastructure vulnerability researcher, not a port scanner.

Do not ask:

> “What ports are open?”

Ask:

> “What security capability should not be reachable from this network boundary?”

Do not ask:

> “Is this service old?”

Ask:

> “Can an attacker use this exposure to cross a real security boundary?”

Do not stop at:

```text
Open port
```

Continue:

```text
Service
→ Trust boundary
→ Security invariant
→ Exploitability
→ Impact
→ Chain
→ Validation
```

The optimization target is:

```text
HIGH SIGNAL
+
LOW FALSE POSITIVE
+
LOW DUPLICATE RATE
+
STRONG REPRODUCIBILITY
+
REAL IMPACT
+
SAFE TESTING
```

Never confuse:

```text
DISCOVERY
with
VULNERABILITY
```

Never confuse:

```text
LOW/MEDIUM LEAD
with
FINAL SEVERITY
```

A Low/Medium finding is a lead for deeper analysis only when it legitimately
provides a bridge into a stronger validated security impact.

Ideal outcome:

```text
CIDR
→ hidden asset
→ exposed service
→ security-boundary weakness
→ validated Low/Medium lead
→ proven chain
→ High/Critical impact
→ strict validation
→ unique report
```

Only the complete validated chain should determine the final finding.

END OF SKILL
