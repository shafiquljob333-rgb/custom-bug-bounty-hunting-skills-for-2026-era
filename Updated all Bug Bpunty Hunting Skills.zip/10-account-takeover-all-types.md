---
name: account-takeover-all-types
description: Comprehensive account-takeover hunter covering authentication, recovery, session, OAuth/OIDC/SAML, MFA, identity-linking and cross-feature chains with strict proof.
version: 2026.08
---

# Account Takeover — All Types Hunter

## Mission
Prove unauthorized control of an account or durable equivalent. A weak login response, token disclosure or reset reflection is not ATO until control is demonstrated safely.

## Attack Surface Map
- login and alternate login endpoints
- password reset / recovery
- email or phone change
- MFA enrollment, reset, recovery and fallback
- session creation, refresh and revocation
- magic links
- invite/accept flows
- OAuth/OIDC social login and account linking
- SAML assertions and SSO mapping
- device trust / remembered devices
- API tokens / personal access tokens
- backup codes
- passwordless authentication
- email verification and identity verification
- subdomain takeover + OAuth/cookie chains

## ATO Classes
### Credential/Session
- session fixation
- session reuse after password or role change
- session revocation failure
- token leakage
- token confusion across audiences/accounts
- insecure “remember me” semantics

### Recovery
- reset-token predictability or reuse
- reset token not bound to account/action
- identity-mixing in recovery
- recovery step skipping
- email/phone change without adequate re-authentication
- verification-state confusion

### OAuth/OIDC/SAML
- redirect validation failure
- state/nonce validation failure
- account-linking CSRF
- code/token mix-up
- issuer/audience/account-binding errors
- identity claim substitution
- SAML assertion validation flaws

### MFA
- MFA bypass through alternate endpoint
- enrollment replacement race
- recovery downgrade
- stale verified state
- OTP abuse only when a real ATO path is demonstrated

## Two-Account Method
For every identity-sensitive action maintain:
- Account A = attacker-controlled
- Account B = second test account
- clear pre-state
- exact expected boundary

Test whether tokens, reset links, verification artifacts, or identifiers created for A can affect B.

## ATO Proof Ladder
1. unauthorized security-sensitive state transition
2. session or credential issuance for unintended principal
3. login to test account B using only attacker-controlled material
4. post-login proof of authority (read a benign private field, change a disposable profile field, or equivalent)

Stop immediately once sufficient ATO proof is established.

## Chain Review
Look for bridges from:
- IDOR → password/email change
- OAuth redirect weakness → code theft → login
- cache poisoning/deception → reset/session data
- subdomain takeover → OAuth/cookie scope
- CSRF/account linking → attacker-controlled identity attachment
- race → verification/token reuse

## Hard Rejections
- account enumeration without control gain
- token-looking strings without successful exchange or authorization use
- self-ATO
- attacks requiring already having the victim’s privileges
- theoretical OAuth redirect problems without code/token exchange proof
