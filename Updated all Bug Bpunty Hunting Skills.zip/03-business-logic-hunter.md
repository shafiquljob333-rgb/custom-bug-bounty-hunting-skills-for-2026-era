---
name: business-logic-hunter
description: Deep business-logic and state-machine hunting skill for authorized bug bounty and pentest targets. Models business invariants, actors, permissions, states, transitions, resources, side effects, rollback, idempotency, cross-service assumptions, verification gates, payments, refunds, subscriptions, coupons, invitations, collaboration, exports, async jobs, and races. Browser-independent and curl-first.
version: 1.0.0
---

# Business Logic Hunter

## Mission

Business logic flaws are not primarily malformed-input bugs. They arise when valid operations can be composed, reordered, repeated, or parameterized in a way that violates the product's intended business rule.

Core principle:

> Technical bugs break the system. Business-logic bugs use the system in an unintended way.

The application may return normal 200 responses and perform every request correctly while still creating financial loss, unauthorized access, free entitlements, duplicate benefits, privilege escalation, or policy violations.

## 0. Start with Business Comprehension

Build:

```text
Business Model
 -> actors
 -> roles
 -> assets
 -> resources
 -> money / credits
 -> trust / verification
 -> critical workflows
 -> irreversible actions
 -> external services
```

Then write the intended rule in plain language.

Example:

```text
A coupon may be consumed once by an account for one eligible order.
```

Convert that into an invariant:

```text
used_count(account,coupon) <= allowed_count
```

The invariant, not the endpoint name, defines the hunt.

## 1. Workflow State Machine

For each critical workflow map:

```text
STATE
ACTOR
PRECONDITIONS
TRANSITION
SERVER CHECK
RESOURCE CONSUMPTION
SIDE EFFECT
ROLLBACK
IDEMPOTENCY
EXPIRATION
RELATED SERVICES
```

Example:

```text
Cart
 -> payment_intent_created
 -> payment_authorized
 -> payment_captured
 -> entitlement_active
```

Ask:

1. Can a user jump from Cart directly to entitlement?
2. Can a canceled payment reach active entitlement?
3. Can an old token recreate a completed state?
4. Can a retry consume the resource twice?
5. Can a second surface create the same state without the same checks?
6. Can two requests pass the same precondition concurrently?

## 2. Hypothesis Generation: “What If?”

For every workflow ask:

```text
What if I skip a step?
What if I repeat a step?
What if I reverse two steps?
What if I replay a successful request?
What if I submit an old state after a new state?
What if I use the same token twice?
What if account A's object is supplied to account B's operation?
What if a client-calculated value is changed?
What if the same action is reachable through REST, GraphQL, mobile, import/export, or a background job?
What if a role changes during the workflow?
What if verification is revoked while a workflow is pending?
```

Each question becomes a hypothesis only after identifying the invariant it could violate.

## 3. High-Value Logic Families

### Payment / Financial

Model authoritative values:

```text
price
subtotal
tax
shipping
currency
quantity
discount
credit
refund
captured amount
subscription tier
entitlement
```

Common hypotheses:

- client-supplied total accepted;
- negative or zero quantity changes arithmetic;
- duplicate coupon consumption;
- coupon stacking beyond allowed rules;
- partial refund can be repeated;
- currency mismatch creates value discrepancy;
- rounding differs across services;
- payment failure still activates entitlement;
- canceled payment leaves access active;
- trial reset reissues the same benefit;
- replayed checkout intent duplicates a side effect.

Use only test accounts/products/credits unless the program explicitly authorizes stronger testing.

### Verification Gates

Model:

```text
Gate prerequisite
 -> gate evidence/token
 -> server enforcement point
 -> protected action
```

Gate examples:

- email verification;
- phone verification;
- MFA;
- KYC;
- age verification;
- payment verification;
- ownership verification;
- invite acceptance;
- admin approval;
- device trust.

High-yield inconsistencies:

```text
one endpoint checks gate, sibling endpoint does not
client hides action but endpoint remains callable
stale verified flag survives role/account state change
evidence belongs to a different account/object
expired token remains valid
race between verification and protected action
```

### Organization / Collaboration

Test invariants around:

- invite acceptance;
- role assignment;
- ownership transfer;
- suspension/removal;
- member restoration;
- billing/admin permissions;
- cross-tenant object references;
- shared resources.

### Credits / Quotas / Inventory

Ask:

```text
Can I consume the same unit twice?
Can I exceed the quota through retries?
Can I transfer a benefit across tenants?
Can a failed transaction leave a positive balance?
```

## 4. Temporal Analysis

Test transitions over time:

```text
T0 before action
T1 during action
T2 immediately after
T3 after logout
T4 after role change
T5 after password reset
T6 after deletion
T7 after expiration
T8 after retry
T9 after re-login
```

Important distinction:

```text
stale data
vs
stale security authority
```

Only the latter becomes a security finding when it crosses an intended boundary.

## 5. Race / TOCTOU

Look for:

```text
check -> await -> mutation
read -> external call -> write
verify token -> consume token
inventory check -> payment -> decrement
coupon check -> order -> mark used
permission check -> async lookup -> privileged action
username availability -> create
```

Proof requirements:

```text
N requests
expected successful operations
actual successful operations
resulting state
invariant violation
```

Use minimal concurrency. Do not stress production.

## 6. Idempotency

Inspect:

- Idempotency-Key;
- unique transaction IDs;
- one-time token consumption;
- replay protection;
- duplicate webhook handling;
- queue retries;
- payment/order/action endpoints.

Differentiate:

```text
intended retry
user duplicate click
safe deduplication
actual duplicate side effect
```

Only the last one is the security candidate.

## 7. Cross-Service / Cross-Surface Collisions

The strongest logic flaws often occur between components:

```text
frontend total
 -> order service
 -> payment service
 -> entitlement service
```

or:

```text
REST update
 -> async worker
 -> cache
 -> notification
```

Ask where the authoritative state lives at each step and whether each service re-validates security-sensitive assumptions.

## 8. Client-Side Values

Never trust:

```text
role
price
discount
verified
subscription
permissions
ownerId
isAdmin
paymentStatus
```

Changing them in a request is only a test of whether the server independently enforces the invariant.

## 9. Business Logic + IDOR Chains

After a confirmed read authorization bug, immediately examine state-changing endpoints using the same object type.

High-value chain shapes:

```text
read object -> discover ID -> refund/withdraw/transfer
read object -> password/email/security mutation -> ATO
read membership -> add/role-change -> privilege escalation
read invoice/order -> financial mutation
```

The second half must be independently demonstrated.

## 10. Business Logic + Curl Workflow

For every key state transition save a request:

```bash
curl -sS -X POST 'https://TARGET/api/workflow/transition' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"testObjectId":"OBJ","transition":"NEXT"}' \
  -D headers.txt -o body.json
```

Then replay the same request with only one invariant violation changed.

## 11. Falsification Loop

Before declaring a logic bug, try to prove it is legitimate:

- Is the benefit intentionally reusable?
- Is the action intended to be idempotent?
- Is the resource already granted by design?
- Is the amount merely a display value?
- Is another server-side condition controlling the final effect?
- Is the observed result eventually rolled back?
- Is the apparent duplicate actually one transaction with multiple representations?

If the result has a benign explanation, discard or continue investigating.

## 12. Impact Model

Business impact should be stated in attacker-capability terms:

```text
unauthorized financial benefit
unauthorized financial loss
free premium entitlement
cross-tenant privilege escalation
ATO
mass data exposure
persistent unauthorized capability
```

Do not inflate with hypothetical mass scale. Prove a representative test case and state the tested scope.

## 13. Business Logic Candidate Record

```yaml
workflow:
business_rule:
invariant:
actor:
resource:
preconditions:
expected_transition:
observed_transition:
request_sequence:
state_before:
state_after:
server_controls_checked:
side_effect:
rollback_behavior:
idempotency:
race_required:
impact:
scale_proven:
design_intent:
status:
```

## 14. Hard Stops

Discard when:

- the rule is intentionally designed that way;
- only UI behavior changes;
- no protected effect occurs;
- no financial/security consequence exists;
- exploitation requires already having the protected authority;
- the issue is purely theoretical;
- concurrency is claimed without a real invariant violation;
- the benefit is already intentionally reusable;
- the same underlying flaw is clearly already covered and no material new value exists.

## 15. Final Handoff

Send confirmed logic candidates to `06-validation-triage-novelty-reporting` with full state history and exact HTTP evidence.
