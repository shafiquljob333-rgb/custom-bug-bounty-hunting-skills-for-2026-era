---
name: high-severity-hunter-orchestrator
description: Master orchestrator for authorized bug-bounty and penetration-testing research. Routes between JS analysis, curl-first HTTP analysis, unauthenticated hunting, authenticated authorization/business-logic testing, and final validation/triage. Optimizes for concrete impact, reproducibility, novelty, and low false-positive/duplicate rates.
version: 1.0.0
---

# High-Severity Hunter Orchestrator

## Mission

Act as an evidence-driven security research agent on explicitly authorized targets. The objective is not to maximize requests or findings. The objective is to maximize the probability that each surviving candidate is:

- in scope;
- genuinely unintended;
- a real security-boundary violation;
- server-side enforced or otherwise demonstrably security-relevant;
- reproducible from raw HTTP or equivalent evidence;
- concretely impactful in the product's business context;
- novel or materially additive;
- non-duplicate;
- precise enough for an independent triager to reproduce;
- tested with minimal unnecessary risk.

The core doctrine is:

> Do not hunt for anomalies. Hunt for violated security invariants.

> Do not prove that something looks dangerous. Prove that an authorized attacker crosses a boundary and gains an unauthorized capability, data access, state transition, or business effect.

> No exact request + no server-side evidence + no demonstrated impact = no finding.

## Authorization Gate

Before active testing, establish:

```text
PROGRAM
  -> ASSET
  -> ENDPOINT / FEATURE
  -> TEST ACCOUNT / OBJECT
  -> AUTHORIZED ACTION
```

Read scope, exclusions, safe-harbor, rate limits, automation restrictions, account requirements, test-data rules, third-party limitations, and prohibited actions.

Never infer authorization from public reachability, DNS, an exposed endpoint, or a related asset.

If scope is ambiguous, keep the branch inactive.

## Mode Gate

Explicitly classify the engagement:

| Mode | Primary standard |
|---|---|
| Bug bounty / VDP | Impact-demonstrated, in-scope, reproducible bugs |
| Pentest | Follow signed scope and rules of engagement |
| Red team | Include security observations and defensive findings when in scope |
| Internal audit | Map findings to required controls/standards |

Do not apply red-team/audit reporting expectations to a bug-bounty submission.

## Product-First Intelligence

Before payloads, build a compact Business Model Map:

```text
Customers / Users
Tenants / Roles
Crown-jewel data
Money / credits / entitlements
Critical workflows
Sensitive actions
Verification gates
Integrations
Async jobs
Admin surfaces
Recovery / identity lifecycle
Trust boundaries
External dependencies
```

For each critical feature define:

```text
WHAT MUST ALWAYS BE TRUE?
WHO MAY DO IT?
ON WHICH RESOURCE?
IN WHICH STATE?
UNDER WHICH PRECONDITIONS?
WHAT SIDE EFFECT IS ALLOWED?
WHAT MUST NEVER HAPPEN?
```

Maintain both:

```text
INTENDED DESIGN
       vs
OBSERVED IMPLEMENTATION
```

The delta is where a strong candidate often lives.

## Historical Intelligence

Treat available historical reports as program-specific security intelligence, not as a guarantee of safety or vulnerability.

For every relevant historical report, extract when available:

- asset/host;
- endpoint/path;
- parameter/object type;
- role/tenant;
- vulnerability class;
- root cause;
- exploitation primitive;
- workflow/state;
- impact;
- remediation;
- status and timing;
- evidence quality.

Use historical density only to prioritize investigation.

Never reason:

```text
no previous report -> therefore vulnerable
```

Instead:

```text
historical signal
 -> priority
 -> security invariant hypothesis
 -> implementation verification
 -> impact verification
```

## Attack Queue

Derive the attack queue from the target.

### Tier A: Highest-value hypotheses

- account ownership or recovery boundaries;
- money, credits, refunds, subscriptions, entitlement;
- cross-tenant and object-level authorization;
- server-side URL fetching/import/PDF generation;
- server-side interpreters or data stores;
- privileged role transitions;
- verification gates;
- asynchronous state transitions and race windows;
- legacy/versioned APIs with inconsistent controls;
- integration/webhook trust boundaries.

### Tier B

- high-impact XSS chains;
- client-side controls that actually gate server behavior;
- sensitive information exposure that unlocks Tier A;
- OAuth/SSO/session lifecycle weaknesses.

### Tier C

- hygiene-only issues;
- missing headers without demonstrated exploitability;
- low-impact disclosure;
- weak rate limiting without meaningful effect.

## Two-Track Hunt Model

Always keep separate:

```text
PRE-AUTH TRACK
POST-AUTH TRACK
```

For post-auth testing, use two dedicated authorized identities when allowed:

```text
ATTACKER TEST ACCOUNT
VICTIM TEST ACCOUNT
```

Use test-created objects. Never use unrelated real-user accounts or data.

## Phase Routing

```text
SCOPE / MODE
   |
   v
PRODUCT + ASSET MAP
   |
   +--> JS surface -> 01-masterjs-analyzer
   |
   +--> raw HTTP / API -> 02-curl-http-operator
   |
   +--> no credentials / public surface -> 04-unauthenticated-hunter
   |
   +--> logged-in workflows -> 05-authenticated-hunter
   |
   +--> payments / workflow / state anomalies -> 03-business-logic-hunter
   |
   v
06-validation-triage-novelty-reporting
```

The flow is non-linear. A newly discovered endpoint can return to mapping; a blocked endpoint can return to recon; a suspected bug can return to design-intent analysis.

## Candidate Lifecycle

```text
OBSERVATION
 -> HYPOTHESIS
 -> FALSIFICATION
 -> SERVER-SIDE PROOF
 -> CAPABILITY PROOF
 -> CONSEQUENCE PROOF
 -> CHAIN ANALYSIS
 -> DESIGN-INTENT CHECK
 -> DUPLICATE / NOVELTY CHECK
 -> FINAL VALIDATION
 -> SEVERITY
 -> REPORT
```

Any failed gate returns the candidate to INVESTIGATE or DISCARD.

## Evidence Ledger

Every material claim must be tagged mentally as:

```text
[OBSERVED]
[VERIFIED]
[DOCUMENTED]
[INFERRED]
[HYPOTHESIS]
[UNKNOWN]
```

Do not present inferred architecture, broad affected scope, or hypothetical chaining as verified impact.

## POC-or-Kill Gate

Before pursuing a candidate for extended time, ask:

1. Can I reproduce the exact HTTP request?
2. Does the server response demonstrate the alleged behavior?
3. Can I identify the protected resource/capability?
4. Can I show the attacker's authorization should fail?
5. Can I demonstrate the security-boundary violation?
6. Can I demonstrate meaningful consequence?
7. Is it in scope?
8. Is it likely novel?

If critical evidence remains hypothetical, stop reporting and either validate further or discard.

## Chain Doctrine

For every confirmed primitive, ask:

> What does this unlock that was not unlocked before?

Important chain shapes include:

```text
read IDOR -> discover state-changing endpoint -> write/delete
read IDOR -> recovery/security-setting mutation -> ATO
unauth endpoint -> identifier disclosure -> object mutation
SSRF -> internal service -> credential/token disclosure -> privilege
information exposure -> credential use -> protected action
business logic -> financial effect -> repeatability / scale
verification bypass -> privileged operation
```

Only include a chain when every link is independently demonstrated or explicitly bounded.

## Severity Discipline

Severity follows demonstrated CIA impact, exploit prerequisites, scope, and business context. High and Critical are impact categories, not a reason to stop verification.

When a concrete finding is ready for scoring, hand it to the CVSS/risk-scoring mechanism if available. Do not inflate severity based on theoretical worst case.

## Mandatory Stop Conditions

Stop a branch when:

- authorization is unclear;
- scope is violated;
- testing risks real-user harm when a safer proof exists;
- the behavior is intentional and documented;
- the attacker is already authorized for the allegedly protected capability;
- no meaningful consequence can be demonstrated;
- only client-side cosmetic behavior changes;
- the evidence is non-reproducible;
- the candidate is already covered without materially new value.

## Final Decision

Only the validation/triage skill may promote a candidate to final-report status.

Final state must be exactly one of:

```text
VALID - REPORT
VALID - CHAINED REPORT
DUPLICATE / REGRESSION REVIEW
INFORMATIVE / NO SECURITY IMPACT
NOT APPLICABLE / OUT OF SCOPE
FALSE POSITIVE - DISCARD
UNPROVEN - RETURN TO HUNT
```
---
name: masterjs-analyzer
description: Browser-independent, CLI-first JavaScript security analysis skill. Discovers JS, source maps, endpoints, parameters, secrets, client-side authorization, DOM XSS flows, prototype-pollution patterns, postMessage handlers, WebSockets, bundler/runtime artifacts, and legacy client behavior using curl and local analysis. Designed to convert client code into server-side test hypotheses; never treats client-only evidence as a confirmed vulnerability.
version: 1.0.0
---

# Master JS Analyzer

## Mission

Treat JavaScript as an attack-surface intelligence source, not as the vulnerability itself.

Primary output:

```text
JS artifact
 -> routes
 -> parameters
 -> auth assumptions
 -> trust boundaries
 -> state transitions
 -> security-sensitive sinks
 -> concrete HTTP hypotheses
 -> server-side verification
```

Client-side evidence becomes a finding only when the server-side behavior creates a real security consequence.

## Input / Output Contract

### Input

- authorized target URL(s);
- downloaded JS or source maps;
- optional API documentation/OpenAPI/GraphQL schema;
- optional authenticated request material that is safe to use on test accounts.

### Output

For every useful lead record:

```yaml
artifact:
route:
method:
parameters:
auth_assumption:
server_test:
expected_secure_behavior:
observed_behavior:
impact_candidate:
evidence:
status: lead|validated|discarded
```

## Phase 0 - Scope and Asset Gate

Confirm every JS URL belongs to an authorized in-scope asset.

Do not pivot from an in-scope domain to an unapproved third-party host merely because a script references it.

## Phase 1 - JS Discovery

### HTML script discovery

```bash
curl -sS --compressed 'https://TARGET/' \
  -H 'User-Agent: Mozilla/5.0' \
  | grep -oE '<script[^>]+src=["\x27][^"\x27]+' \
  | sed -E 's/.*src=["\x27]//' \
  | sort -u
```

### Standard locations

Check framework-specific paths conservatively and only on the authorized asset:

```text
/static/js/
/assets/
/_next/static/
/_nuxt/
/js/
/build/
/dist/
```

Do not brute-force enormous chunk ranges. Start from references in HTML, JS runtime manifests, preload tags, and source maps.

### Historical JS discovery

Use authorized/public archival data only for discovery. Treat old URLs as leads, not as permission to test unrelated infrastructure.

Useful tools when available:

```bash
gau TARGET | grep -E '\.js([?#]|$)' | sort -u
gospider -s 'https://TARGET' --js -d 3
katana -u 'https://TARGET' -jc -d 3
```

## Phase 2 - Download and Normalize

```bash
mkdir -p js/{raw,pretty,maps,sourcemap}

curl -sS --compressed 'https://TARGET/app.js' -o js/raw/app.js
file js/raw/app.js
wc -c js/raw/app.js
head -c 200 js/raw/app.js
```

Record:

- URL;
- response status;
- Content-Type;
- Content-Length;
- ETag/Last-Modified where present;
- hash of downloaded artifact.

A hash lets the agent distinguish a new build from the same artifact seen earlier.

## Phase 3 - Source Maps

Detect:

```bash
curl -sS 'https://TARGET/app.js' | tail -n 5 | grep -i 'sourceMappingURL'
curl -sS -o /dev/null -w '%{http_code} %{content_type} %{size_download}\n' 'https://TARGET/app.js.map'
```

If accessible and in scope:

```bash
curl -sS 'https://TARGET/app.js.map' -o js/maps/app.js.map
python3 -m json.tool js/maps/app.js.map | head -40
```

Use local extraction tools such as `sourcemapper`/`unwebpack_sourcemap` when available.

### Source-map triage

High-value signals:

- unminified authorization logic;
- internal-only route names;
- feature flags;
- server endpoint definitions;
- hidden GraphQL operations;
- test/debug paths;
- environment variable references;
- comments containing TODO/FIXME/HACK/DEBUG;
- source code that reveals server-side trust assumptions.

Do not report the mere existence of a source map unless the exposed source itself creates a meaningful security consequence under the program's policy.

## Phase 4 - Endpoint and Parameter Extraction

Use `jsluice`, LinkFinder, grep, parser scripts, or equivalent local analysis.

Useful patterns:

```bash
grep -rEo 'https?://[^"\x27 )]+' js/raw js/sourcemap | sort -u
grep -rEo '/(api|graphql|oauth|auth|admin|internal|v[0-9]+)[A-Za-z0-9_./?=&{}:-]*' js/raw js/sourcemap | sort -u

grep -rEin 'fetch\(|axios\.|\.get\(|\.post\(|\.put\(|\.patch\(|\.delete\(|XMLHttpRequest|WebSocket' js/raw js/sourcemap | head -200
```

Extract parameter names from:

- query strings;
- URL templates;
- JSON bodies;
- GraphQL variables;
- multipart metadata;
- headers;
- path segments.

Group routes by business object:

```text
/users/{id}
/orders/{id}
/invoices/{id}
/files/{id}
/organizations/{id}
/projects/{id}
```

## Phase 5 - Client-Side Authorization Analysis

Search for:

```text
role
permission
isAdmin
isOwner
can*
featureFlag
verified
subscription
entitlement
organizationId
tenantId
```

A client check is only a hypothesis.

For example:

```js
if (user.role === 'admin') showDeleteButton()
```

does not prove a vulnerability.

Convert it into:

```text
Which endpoint performs the delete?
Does that endpoint enforce the same role server-side?
Can the test account invoke it directly?
```

## Phase 6 - DOM XSS Data-Flow Analysis

### Sources

```text
location.search
location.hash
location.href
location.pathname
document.referrer
postMessage data
localStorage/sessionStorage values
URLSearchParams
```

### Sinks

```text
innerHTML
outerHTML
document.write
eval
new Function
setTimeout(string)
setInterval(string)
location.assign/location.replace
src/href assignments
```

Use source-to-sink reasoning, not keyword matching.

A sink is a lead only until attacker-controlled input is demonstrated to reach it in an executable context.

Where a browser is unavailable, first prove the data-flow statically and then use a minimal, browser-independent server-side or reflective observation where possible. Do not claim execution without execution evidence.

## Phase 7 - postMessage

Search:

```bash
grep -rEin 'addEventListener\(["\x27]message|onmessage|postMessage\(' js/ | head -100
```

For each handler, model:

```text
source window
origin validation
message structure validation
sink
privileged action
```

High-confidence cases require evidence that an untrusted origin can influence a security-relevant action or sensitive data flow.

String checks such as `includes('target.com')` are suspicious, not automatically vulnerable.

## Phase 8 - Prototype Pollution

Search for:

```text
__proto__
constructor.prototype
Object.assign
merge
extend
clone
set(path, value)
recursive object assignment
```

Classify separately:

- client-side pollution only;
- server-side object pollution;
- pollution that changes a security decision;
- pollution that reaches a dangerous gadget.

Only the final security effect determines reportability.

## Phase 9 - Secrets and Credentials

Use high-precision scanners first:

```bash
trufflehog filesystem js/sourcemap --only-verified
gitleaks detect --source js/sourcemap -v
jsluice secrets js/raw/app.js
```

Then inspect manually.

Classify candidate strings:

```text
public identifier
public client key
publishable key
non-secret configuration
credential
session token
private signing key
database credential
third-party secret
```

A value is a finding only when:

1. it is actually secret or privileged;
2. it is accessible to an unauthorized party;
3. it is valid/current or otherwise useful;
4. its use is authorized only within the intended trust boundary;
5. impact is demonstrated safely.

Do not test destructive actions with discovered credentials.

## Phase 10 - Framework / Bundler Intelligence

Recognize common artifacts:

```text
React / CRA -> /static/js/*.chunk.js
Next.js -> /_next/static/
Angular -> /main.*.js /runtime.*.js
Vue -> /js/app.*.js
Nuxt -> /_nuxt/
Vite -> /assets/*.js
```

Look for:

- route registries;
- API base URLs;
- environment variable names;
- GraphQL operation names;
- feature flag names;
- legacy API versions;
- accidentally bundled server-only imports.

## Phase 11 - WebSocket Surface

Search:

```bash
grep -rEin 'new WebSocket|ws://|wss://|socket\.io|\.emit\(|\.send\(' js/ | head -100
```

Map message types and authorization assumptions.

Do not claim message-level authorization bypass until a test identity can perform a prohibited message successfully.

## Phase 12 - Legacy / Alternate Surface Comparison

For every important route discovered in JS, search for:

```text
v1/v2/v3
legacy
mobile
internal
admin
graphql
rest
batch
export
import
share
notification
```

Compare the same operation across surfaces.

The key question:

> Does one implementation enforce a security invariant while a sibling implementation does not?

## Phase 13 - JS Candidate Scoring

Prioritize:

1. route + sensitive object + missing backend authorization evidence;
2. token/secret with demonstrable privileged use;
3. URL-driven dangerous sink with executable consequence;
4. privileged message handler lacking trusted-origin enforcement;
5. hidden endpoint with materially weaker server controls;
6. source-map discovery that reveals exploitable server assumptions.

Deprioritize:

- source maps with no additional impact;
- public identifiers;
- dead code;
- client-only role checks where the server is secure;
- vulnerable library versions without reachable/exploitable behavior.

## Phase 14 - Required HTTP Conversion

Every promising JS lead must produce an HTTP hypothesis:

```text
JS route
 -> HTTP method
 -> required headers/cookies
 -> request body/query
 -> expected authorized context
 -> unauthorized test context
 -> response comparison
 -> impact proof
```

The next skill should normally be `02-curl-http-operator`.

## Final Gate

Do not report JS findings based only on source code. Require:

```text
source evidence
+
HTTP/server evidence
+
concrete impact
+
scope
+
novelty
```

## Evidence Template

```yaml
js_url:
artifact_hash:
route:
method:
source_location:
source_behavior:
security_assumption:
http_request:
http_response:
authorization_context:
impact:
chain:
design_intent:
duplicate_status:
final_status:
```
---
name: curl-http-operator
description: Browserless curl-first HTTP research skill for authorized bug bounty and pentest work. Captures, normalizes, mutates, compares, and validates HTTP requests using curl, shell, jq, grep, and small local scripts. Optimized for reproducible raw requests, authenticated/unauthenticated differentials, state transitions, error analysis, and evidence collection without relying on a browser.
version: 1.0.0
---

# Curl HTTP Operator

## Mission

Operate at the HTTP protocol level when a browser is unavailable or intentionally avoided.

The unit of work is:

```text
REQUEST
 -> RESPONSE
 -> COMPARISON
 -> SECURITY INVARIANT
 -> PROOF
```

Never use curl merely to generate traffic. Every request belongs to a hypothesis.

## Safety Contract

- authorized targets only;
- use dedicated test accounts and objects;
- use non-destructive proofs whenever possible;
- avoid production load and excessive concurrency;
- respect program rate limits;
- do not expose or publish real credentials unnecessarily;
- sanitize sensitive evidence before final reporting unless the secret exposure itself is the finding.

## 0. Tooling Baseline

Recommended local tools:

```bash
curl
jq
grep
gawk
grep -P / perl when available
python3
sed
awk
openssl
sha256sum
```

Optional:

```bash
httpie
fzf
xargs
parallel
```

## 1. Canonical Request Capture

For every important request save:

```text
method
full URL
query string
request headers
cookies
authorization header
content type
body
response status
response headers
response body
redirect chain
timing
```

Prefer explicit files:

```bash
mkdir -p evidence/{requests,responses,meta}
```

### Verbose request

```bash
curl -sS -D evidence/responses/headers.txt \
  -o evidence/responses/body.txt \
  -w '\nSTATUS=%{http_code}\nTIME=%{time_total}\nSIZE=%{size_download}\n' \
  'https://TARGET/api/object/123' \
  -H 'Accept: application/json' \
  -H 'User-Agent: HighSeverityHunter/1.0'
```

When debugging transport:

```bash
curl -v 'https://TARGET/'
```

Do not rely on `-v` alone for the final evidence because it mixes transport and application output. Save clean headers/body separately.

## 2. Cookie and Session Handling

Use a cookie jar for dedicated test accounts:

```bash
curl -sS -c cookies-a.txt -b cookies-a.txt 'https://TARGET/login'
```

Never share session jars between attacker and victim test identities.

Keep explicit labels:

```text
COOKIE_A = attacker test account
COOKIE_B = victim test account
```

## 3. Auth Header Patterns

Cookie session:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'Cookie: session=REDACTED'
```

Bearer token:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'Authorization: Bearer REDACTED'
```

API key:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'X-API-Key: REDACTED'
```

Do not assume all accepted credentials are equivalent. Test the actual authorization boundary.

## 4. Baseline / Mutation / Differential Pattern

The most important curl pattern:

```text
BASELINE
  -> ONE CHANGE
  -> RESPONSE DIFFERENCE
  -> REPEAT
  -> CONTROL CASE
```

Never mutate many variables at once unless testing parser interactions intentionally.

Example:

```bash
curl -sS 'https://TARGET/api/orders/100' -H 'Cookie: session=COOKIE_A' > a.json
curl -sS 'https://TARGET/api/orders/101' -H 'Cookie: session=COOKIE_A' > b.json

diff -u a.json b.json
```

A difference is evidence of behavior, not proof of a vulnerability.

## 5. Method Differential Testing

Compare equivalent operations:

```text
GET vs POST
PUT vs PATCH
DELETE vs POST
HEAD vs GET
/api/v1 vs /api/v2
JSON vs form-urlencoded
single vs batch
```

Use this to detect inconsistent authorization/validation.

Example:

```bash
for method in GET POST PUT PATCH DELETE; do
  curl -sS -X "$method" 'https://TARGET/api/object/123' \
    -H 'Cookie: session=COOKIE_A' \
    -H 'Accept: application/json' \
    -o /tmp/body \
    -w "$method %{http_code} %{size_download}\n"
done
```

Only investigate methods that the application legitimately exposes or appears to recognize.

## 6. Header Differential Testing

Useful for identifying routing/auth assumptions:

```text
Authorization
Cookie
Origin
Referer
X-Requested-With
Content-Type
Accept
Accept-Language
User-Agent
```

Proxy metadata such as `X-Forwarded-For` must not be sprayed indiscriminately. Only test when the application appears to use client-IP metadata for a security decision and the program allows such testing.

## 7. Request Body Mutation

JSON:

```bash
curl -sS -X POST 'https://TARGET/api/update' \
  -H 'Content-Type: application/json' \
  -H 'Cookie: session=COOKIE_A' \
  --data '{
  "safe_field":"value"
}'
```

Form:

```bash
curl -sS -X POST 'https://TARGET/api/update' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Cookie: session=COOKIE_A' \
  --data 'safe_field=value'
```

XML:

```bash
curl -sS -X POST 'https://TARGET/api/import' \
  -H 'Content-Type: application/xml' \
  --data '<request><id>123</id></request>'
```

Multipart:

```bash
curl -sS -X POST 'https://TARGET/api/upload' \
  -H 'Cookie: session=COOKIE_A' \
  -F 'file=@test.txt' \
  -F 'description=test'
```

## 8. HTTP Response Fingerprinting

Capture a compact fingerprint:

```bash
curl -sS -D /tmp/h -o /tmp/b \
  -w 'code=%{http_code} type=%{content_type} bytes=%{size_download} time=%{time_total} redirect=%{url_effective}\n' \
  'https://TARGET/api/object/123'

printf '\n-- headers --\n'; sed -n '1,80p' /tmp/h
printf '\n-- body --\n'; sed -n '1,120p' /tmp/b
```

Useful comparison features:

- status code;
- Content-Type;
- Location;
- WWW-Authenticate;
- Set-Cookie;
- body length;
- stable JSON keys;
- object identifiers;
- error codes/messages;
- response timing.

Timing alone is rarely proof. Require repeatability and a meaningful side effect or data distinction.

## 9. JSON Differential Extraction

Use `jq` to compare structured responses:

```bash
jq -S . response.json > normalized.json
jq -r '.id, .ownerId, .role, .status' response.json
```

For array scope:

```bash
jq -r '.items[] | [.id,.ownerId,.status] | @tsv' response.json
```

For a suspected authorization differential:

```bash
jq -S '{status,ownerId,id,permissions,data}' a.json > a.norm
jq -S '{status,ownerId,id,permissions,data}' b.json > b.norm
diff -u a.norm b.norm
```

## 10. Unauthenticated Differential

Use three controls whenever possible:

```text
Unauth -> Object A
Auth A -> Object A
Unauth -> intentionally public object
```

A secure system may intentionally return a public representation while denying private fields.

The correct question is:

> Does the unauthenticated actor receive a protected capability or protected data that the application intends to reserve?

## 11. Two-Account Authorization Differential

The canonical matrix:

```text
A -> A's object       expected ALLOW
A -> B's object       expected DENY
B -> B's object       expected ALLOW
Unauth -> A's object  expected DENY when private
Low role -> privileged object expected DENY
Cross tenant -> same object ID expected DENY
```

Example:

```bash
curl -sS 'https://TARGET/api/orders/ORDER_A' -H 'Cookie: session=COOKIE_A' > a-a.json
curl -sS 'https://TARGET/api/orders/ORDER_B' -H 'Cookie: session=COOKIE_A' > a-b.json
curl -sS 'https://TARGET/api/orders/ORDER_B' -H 'Cookie: session=COOKIE_B' > b-b.json
```

The finding is the unauthorized differential, not merely the changed identifier.

## 12. Auth Boundary Checks

Test, when relevant:

```text
missing Cookie
expired Cookie
revoked token
wrong-account token
wrong-tenant token
old session after logout
old session after password reset
old token after role downgrade
```

Example:

```bash
curl -sS 'https://TARGET/api/me' \
  -H 'Cookie: session=REVOKED' \
  -o /tmp/r \
  -w '%{http_code} %{size_download}\n'
```

A successful response is not automatically a vulnerability. Confirm what authority remains and whether the security model requires revocation.

## 13. State-Machine Testing with curl

Represent a workflow as:

```text
S0 -> S1 -> S2 -> S3
```

For each transition capture the request and response.

Then test safe invalid transitions:

```text
S0 -> S2
S1 -> S3
S2 -> S1
S3 -> S2 after expiry/revocation
retry S2 -> S3
```

Examples:

```bash
curl -sS -X POST 'https://TARGET/api/checkout/complete' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"orderId":"TEST_ORDER"}'
```

Only use test-created orders/products/credits for financial flows unless the program explicitly permits otherwise.

## 14. Verification Gate Testing

Map:

```text
Gate -> evidence/token -> enforcement point -> protected action
```

Test one invariant at a time:

- remove verification evidence;
- replay evidence in the same authorized test account where permitted;
- use expired evidence;
- use evidence from test account A on test account B;
- call sibling protected endpoints directly.

The strongest evidence is a protected action succeeding without the required security condition.

## 15. Information Disclosure Validation

When an endpoint exposes interesting data, classify the data first.

Use:

```bash
jq 'keys' response.json
jq 'del(.publicField1,.publicField2)' response.json
```

Ask:

- Is it intentionally public?
- Is it documented?
- Is it already delivered to normal users?
- Is it a public client identifier?
- Is it a secret credential?
- Does it unlock another protected action?

Never escalate a report solely because a value “looks internal.”

## 16. Redirect and SSRF Evidence

Redirect:

```bash
curl -sS -D - -o /dev/null 'https://TARGET/login?next=https%3A%2F%2Fexample.com'
```

SSRF discovery should stay bounded and safe. Prefer a collaborator/callback service supplied by the authorized assessment or a harmless endpoint you control. Do not probe internal infrastructure broadly.

Proof hierarchy:

```text
URL accepted
 < server makes outbound request
 < callback proves target server made request
 < response/body proves internal data read
 < protected internal capability obtained
```

A callback is stronger than mere URL acceptance, and actual protected-data access is stronger than a blind callback.

## 17. Injection Testing Pattern

For SQL/NoSQL/template/command-like inputs, follow:

```text
baseline
 -> harmless syntax mutation
 -> error differential
 -> boolean differential
 -> timing differential if justified
 -> bounded proof
```

Do not perform destructive DB writes, destructive commands, or high-volume extraction on production systems.

Timing tests must use small, repeatable delays and controls.

### Minimal timing collection

```bash
for i in 1 2 3 4 5; do
  curl -sS -o /dev/null -w '%{time_total}\n' \
    'https://TARGET/api/search?q=SAFE_TEST'
done
```

Compare against an equivalent control request before attributing timing to injection.

## 18. Safe Race Testing

Races require evidence of an invariant violation, not just concurrency.

Minimum proof set:

```text
number of concurrent requests
expected successes
actual successes
state before
state after
invariant violated
```

Use the smallest practical concurrency, test objects, and bounded bursts.

Example pattern:

```bash
seq 1 3 | xargs -n1 -P3 -I{} curl -sS -X POST \
  'https://TARGET/api/test-action' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"testObjectId":"OBJ"}'
```

Three requests are illustrative, not a mandate. Increase only when the program permits it and the signal cannot be established otherwise.

## 19. Reproducibility Harness

Create a deterministic script:

```bash
#!/usr/bin/env bash
set -euo pipefail
BASE='https://TARGET'
COOKIE='REDACTED'

curl -sS "$BASE/api/test-object/OBJ" \
  -H "Cookie: session=$COOKIE" \
  -H 'Accept: application/json' \
  -D headers.txt -o body.json

printf 'HTTP body hash: '
sha256sum body.json
```

A stranger should be able to understand the exact request sequence from the saved script.

## 20. Evidence Package

For each candidate save:

```text
00-scope.txt
01-baseline.request
01-baseline.response.headers
01-baseline.response.body
02-mutated.request
02-mutated.response.headers
02-mutated.response.body
03-control.request
03-control.response
04-analysis.md
05-impact.md
```

Do not store reusable real credentials in the final package.

## 21. Curl Anti-Patterns

Do not:

- blindly fuzz thousands of parameters;
- treat 200 as vulnerability proof;
- infer auth bypass from a different error page only;
- trust a client-supplied role/price/verification flag without testing the protected effect;
- rotate spoofed IP headers unless the IP is actually a relevant security control;
- claim SSRF from a parser accepting `http://`;
- claim SQLi from an isolated 500 error;
- claim IDOR from an accessible object that is intentionally public;
- use timing differences without repeatability/control;
- report a request that cannot be reproduced.

## 22. Final Handoff

When curl establishes a candidate, provide:

```yaml
exact_request:
exact_response:
control_request:
control_response:
security_invariant:
unauthorized_capability:
concrete_impact:
repro_steps:
design_intent_status:
novelty_status:
```

Then route to `06-validation-triage-novelty-reporting`.
---
name: business-logic-hunter
description: Deep business-logic and state-machine hunting skill for authorized bug bounty and pentest targets. Models business invariants, actors, permissions, states, transitions, resources, side effects, rollback, idempotency, cross-service assumptions, verification gates, payments, refunds, subscriptions, coupons, invitations, collaboration, exports, async jobs, and races. Browser-independent and curl-first.
version: 1.0.0
---

# Business Logic Hunter

## Mission

Business logic flaws are not primarily malformed-input bugs. They arise when valid operations can be composed, reordered, repeated, or parameterized in a way that violates the product's intended business rule.

Core principle:

> Technical bugs break the system. Business-logic bugs use the system in an unintended way.

The application may return normal 200 responses and perform every request correctly while still creating financial loss, unauthorized access, free entitlements, duplicate benefits, privilege escalation, or policy violations.

## 0. Start with Business Comprehension

Build:

```text
Business Model
 -> actors
 -> roles
 -> assets
 -> resources
 -> money / credits
 -> trust / verification
 -> critical workflows
 -> irreversible actions
 -> external services
```

Then write the intended rule in plain language.

Example:

```text
A coupon may be consumed once by an account for one eligible order.
```

Convert that into an invariant:

```text
used_count(account,coupon) <= allowed_count
```

The invariant, not the endpoint name, defines the hunt.

## 1. Workflow State Machine

For each critical workflow map:

```text
STATE
ACTOR
PRECONDITIONS
TRANSITION
SERVER CHECK
RESOURCE CONSUMPTION
SIDE EFFECT
ROLLBACK
IDEMPOTENCY
EXPIRATION
RELATED SERVICES
```

Example:

```text
Cart
 -> payment_intent_created
 -> payment_authorized
 -> payment_captured
 -> entitlement_active
```

Ask:

1. Can a user jump from Cart directly to entitlement?
2. Can a canceled payment reach active entitlement?
3. Can an old token recreate a completed state?
4. Can a retry consume the resource twice?
5. Can a second surface create the same state without the same checks?
6. Can two requests pass the same precondition concurrently?

## 2. Hypothesis Generation: “What If?”

For every workflow ask:

```text
What if I skip a step?
What if I repeat a step?
What if I reverse two steps?
What if I replay a successful request?
What if I submit an old state after a new state?
What if I use the same token twice?
What if account A's object is supplied to account B's operation?
What if a client-calculated value is changed?
What if the same action is reachable through REST, GraphQL, mobile, import/export, or a background job?
What if a role changes during the workflow?
What if verification is revoked while a workflow is pending?
```

Each question becomes a hypothesis only after identifying the invariant it could violate.

## 3. High-Value Logic Families

### Payment / Financial

Model authoritative values:

```text
price
subtotal
tax
shipping
currency
quantity
discount
credit
refund
captured amount
subscription tier
entitlement
```

Common hypotheses:

- client-supplied total accepted;
- negative or zero quantity changes arithmetic;
- duplicate coupon consumption;
- coupon stacking beyond allowed rules;
- partial refund can be repeated;
- currency mismatch creates value discrepancy;
- rounding differs across services;
- payment failure still activates entitlement;
- canceled payment leaves access active;
- trial reset reissues the same benefit;
- replayed checkout intent duplicates a side effect.

Use only test accounts/products/credits unless the program explicitly authorizes stronger testing.

### Verification Gates

Model:

```text
Gate prerequisite
 -> gate evidence/token
 -> server enforcement point
 -> protected action
```

Gate examples:

- email verification;
- phone verification;
- MFA;
- KYC;
- age verification;
- payment verification;
- ownership verification;
- invite acceptance;
- admin approval;
- device trust.

High-yield inconsistencies:

```text
one endpoint checks gate, sibling endpoint does not
client hides action but endpoint remains callable
stale verified flag survives role/account state change
evidence belongs to a different account/object
expired token remains valid
race between verification and protected action
```

### Organization / Collaboration

Test invariants around:

- invite acceptance;
- role assignment;
- ownership transfer;
- suspension/removal;
- member restoration;
- billing/admin permissions;
- cross-tenant object references;
- shared resources.

### Credits / Quotas / Inventory

Ask:

```text
Can I consume the same unit twice?
Can I exceed the quota through retries?
Can I transfer a benefit across tenants?
Can a failed transaction leave a positive balance?
```

## 4. Temporal Analysis

Test transitions over time:

```text
T0 before action
T1 during action
T2 immediately after
T3 after logout
T4 after role change
T5 after password reset
T6 after deletion
T7 after expiration
T8 after retry
T9 after re-login
```

Important distinction:

```text
stale data
vs
stale security authority
```

Only the latter becomes a security finding when it crosses an intended boundary.

## 5. Race / TOCTOU

Look for:

```text
check -> await -> mutation
read -> external call -> write
verify token -> consume token
inventory check -> payment -> decrement
coupon check -> order -> mark used
permission check -> async lookup -> privileged action
username availability -> create
```

Proof requirements:

```text
N requests
expected successful operations
actual successful operations
resulting state
invariant violation
```

Use minimal concurrency. Do not stress production.

## 6. Idempotency

Inspect:

- Idempotency-Key;
- unique transaction IDs;
- one-time token consumption;
- replay protection;
- duplicate webhook handling;
- queue retries;
- payment/order/action endpoints.

Differentiate:

```text
intended retry
user duplicate click
safe deduplication
actual duplicate side effect
```

Only the last one is the security candidate.

## 7. Cross-Service / Cross-Surface Collisions

The strongest logic flaws often occur between components:

```text
frontend total
 -> order service
 -> payment service
 -> entitlement service
```

or:

```text
REST update
 -> async worker
 -> cache
 -> notification
```

Ask where the authoritative state lives at each step and whether each service re-validates security-sensitive assumptions.

## 8. Client-Side Values

Never trust:

```text
role
price
discount
verified
subscription
permissions
ownerId
isAdmin
paymentStatus
```

Changing them in a request is only a test of whether the server independently enforces the invariant.

## 9. Business Logic + IDOR Chains

After a confirmed read authorization bug, immediately examine state-changing endpoints using the same object type.

High-value chain shapes:

```text
read object -> discover ID -> refund/withdraw/transfer
read object -> password/email/security mutation -> ATO
read membership -> add/role-change -> privilege escalation
read invoice/order -> financial mutation
```

The second half must be independently demonstrated.

## 10. Business Logic + Curl Workflow

For every key state transition save a request:

```bash
curl -sS -X POST 'https://TARGET/api/workflow/transition' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"testObjectId":"OBJ","transition":"NEXT"}' \
  -D headers.txt -o body.json
```

Then replay the same request with only one invariant violation changed.

## 11. Falsification Loop

Before declaring a logic bug, try to prove it is legitimate:

- Is the benefit intentionally reusable?
- Is the action intended to be idempotent?
- Is the resource already granted by design?
- Is the amount merely a display value?
- Is another server-side condition controlling the final effect?
- Is the observed result eventually rolled back?
- Is the apparent duplicate actually one transaction with multiple representations?

If the result has a benign explanation, discard or continue investigating.

## 12. Impact Model

Business impact should be stated in attacker-capability terms:

```text
unauthorized financial benefit
unauthorized financial loss
free premium entitlement
cross-tenant privilege escalation
ATO
mass data exposure
persistent unauthorized capability
```

Do not inflate with hypothetical mass scale. Prove a representative test case and state the tested scope.

## 13. Business Logic Candidate Record

```yaml
workflow:
business_rule:
invariant:
actor:
resource:
preconditions:
expected_transition:
observed_transition:
request_sequence:
state_before:
state_after:
server_controls_checked:
side_effect:
rollback_behavior:
idempotency:
race_required:
impact:
scale_proven:
design_intent:
status:
```

## 14. Hard Stops

Discard when:

- the rule is intentionally designed that way;
- only UI behavior changes;
- no protected effect occurs;
- no financial/security consequence exists;
- exploitation requires already having the protected authority;
- the issue is purely theoretical;
- concurrency is claimed without a real invariant violation;
- the benefit is already intentionally reusable;
- the same underlying flaw is clearly already covered and no material new value exists.

## 15. Final Handoff

Send confirmed logic candidates to `06-validation-triage-novelty-reporting` with full state history and exact HTTP evidence.
---
name: unauthenticated-hunter
description: Deep pre-authentication hunting skill for authorized targets. Maps everything reachable without credentials and tests authentication boundaries, public/private exposure, IDOR-like access, SSRF, injection, RCE candidates, verification bypasses, account recovery, OAuth/SSO, legacy endpoints, upload/import flows, and other pre-auth surfaces with curl-first proof and strict false-positive controls.
version: 1.0.0
---

# Unauthenticated Hunter

## Mission

Find real security-boundary failures that allow a pre-authenticated attacker to obtain capabilities, data, or state transitions reserved for authenticated or otherwise trusted actors.

The question is never:

> “Can I reach this endpoint without a cookie?”

The question is:

> “What protected capability or protected data does the unauthenticated actor gain, and is that outside the intended public design?”

## 0. Pre-Auth Surface Map

Enumerate:

```text
login
registration
password reset
account recovery
email verification
phone verification
OAuth / SSO initiation and callback
invite acceptance
public search
public object sharing
public APIs
file access
file upload/import
webhooks
URL fetchers
PDF/rendering
GraphQL
legacy APIs
health/debug/admin surfaces
mobile API routes
```

Build a table:

| Surface | Expected auth | Actual auth | Protected object/capability | Candidate |
|---|---|---|---|---|

## 1. Baseline Without Credentials

For each endpoint:

```bash
curl -sS -D /tmp/h -o /tmp/b 'https://TARGET/PATH'
printf 'status=%s bytes=%s type=%s\n' \
  "$(awk 'toupper($1) ~ /^HTTP/ {code=$2} END{print code}' /tmp/h)" \
  "$(wc -c </tmp/b)" \
  "$(grep -i '^content-type:' /tmp/h | tail -1)"
```

Compare against an authenticated request when a test account exists.

## 2. Public vs Private vs Internal

Do not classify by appearance.

For any unauthenticated response, establish:

1. Is this intentionally public?
2. Is it documented?
3. Does it expose only a public representation?
4. Does it contain user-private data?
5. Does it expose credentials or security tokens?
6. Does it unlock another protected action?
7. Is the resource accessible through ordinary product UX?
8. Is the response already delivered to anonymous users by design?

A route returning 200 is not a vulnerability.

## 3. Authentication Boundary Differential

Compare:

```text
Unauth -> protected object
Auth A -> A's object
Auth A -> B's object
```

When the product has public resources, also use:

```text
Unauth -> public object
Unauth -> private object
```

A strong finding demonstrates that private behavior is indistinguishable from or incorrectly granted to pre-auth callers.

## 4. Unauthenticated IDOR / Object-Level Authorization

Search for object references in:

```text
path IDs
query IDs
JSON IDs
GraphQL IDs
export IDs
share tokens
file IDs
order IDs
invoice IDs
user IDs
organization IDs
```

Test only test objects and identifiers legitimately available to the tester.

Example:

```bash
curl -sS 'https://TARGET/api/profile/TEST_PRIVATE_OBJECT' \
  -D unauth.headers -o unauth.body
```

If the object should be private, compare it with the owner's authenticated response.

Do not assume randomness makes an IDOR impossible. The important question is whether a reliable identifier acquisition path exists and whether server-side authorization is missing.

## 5. Legacy / Versioned Auth Bypass

Compare:

```text
/api/v1/
/api/v2/
/api/
/mobile/
/graphql
/rest
legacy routes
```

Look for inconsistent authentication middleware or object-level checks.

Do not report version differences unless the unauthenticated or low-privileged path actually reaches a protected capability.

## 6. Authentication and Session Boundary Testing

High-value areas:

- session creation;
- token exchange;
- password reset;
- account recovery;
- email/phone verification;
- OAuth callbacks;
- magic links;
- invite acceptance.

Test whether a pre-auth state can be upgraded to a privileged state without satisfying the intended proof.

## 7. Recovery / Reset Flows

Model:

```text
request recovery
 -> proof / token
 -> verification
 -> credential change
 -> authenticated session
```

Hypotheses:

- token not bound to intended account;
- token accepted after expiration/reuse;
- protected step skipped;
- reset endpoint fails to enforce recovery proof;
- recovery changes sensitive identity state without sufficient assurance.

Use only test accounts.

## 8. Verification Gate Bypass

Test:

```text
email verification
phone verification
MFA preconditions
KYC / identity proof
device trust
invite acceptance
admin approval
payment verification
```

For each:

```text
precondition
 -> evidence
 -> server enforcement
 -> protected action
```

A valid finding requires the protected action to succeed without the required gate.

## 9. SSRF Pre-Auth Surface

Prioritize features that accept URLs:

```text
import from URL
fetch URL
webhook tester
image/PDF fetcher
URL preview
link unfurling
remote file upload
feed importer
callback verifier
```

Proof hierarchy:

```text
URL parser accepts arbitrary URL
 < server makes outbound request
 < controlled callback proves server-side request
 < response reveals protected internal content
```

Use only a controlled callback endpoint or approved collaborator service.

Do not broadly scan internal address ranges or cloud metadata without explicit authorization.

## 10. Pre-Auth SSRF Chaining

Potential chain:

```text
unauthenticated URL fetch
 -> internal service reachable
 -> sensitive response returned
 -> credential/token acquired
 -> protected capability
```

Every link must be demonstrated or clearly bounded.

## 11. SQL / NoSQL Injection Pre-Auth

Map input surfaces:

```text
search
filter
sort
login
username
email
IDs
pagination
GraphQL variables
JSON query objects
```

Use the safest sequence:

```text
baseline
 -> harmless syntax probe
 -> response/error differential
 -> boolean differential
 -> timing if justified
```

An error alone does not prove injection.

## 12. RCE Candidates Pre-Auth

Prioritize server-side execution surfaces:

```text
template rendering
file processing
archive extraction
image/PDF conversion
command wrappers
code evaluation
plugin/config loaders
deserialization
```

Require an actual server-side effect. A string appearing in an error is not RCE.

Do not deploy persistent shells or destructive payloads in production bounty environments.

## 13. File Upload / Import

Map:

```text
upload endpoint
metadata
filename
content type
storage path
preview/transformer
asynchronous processing
public retrieval
```

Security questions:

- can an unauthenticated user upload?
- is the uploaded file executed or interpreted?
- can it escape intended storage?
- can the server process attacker-controlled content dangerously?
- does the result become public?

Use harmless test files.

## 14. OAuth / SSO Pre-Auth

Map:

```text
authorize
callback
token exchange
redirect_uri
state
nonce
linking
login initiation
```

Test the security invariants:

```text
redirect target is bound to client
state is bound to session/flow
nonce is validated where applicable
callback belongs to the intended transaction
account linking requires the right identity proof
```

A redirect parameter reflecting attacker input is not automatically a vulnerability; demonstrate token/code or account-boundary impact.

## 15. Public API / GraphQL

For GraphQL, map operations and object access.

Compare the same object through:

```text
REST endpoint
GraphQL query
node/global ID
batch endpoint
export endpoint
```

A GraphQL introspection result alone is usually attack-surface intelligence. Report only demonstrated security consequences.

## 16. Information Disclosure

High-value pre-auth disclosures include:

- credentials;
- active session material;
- reset tokens;
- private user data;
- cross-tenant data;
- private object content;
- internal data that directly unlocks a protected capability.

Low-value observations such as public keys, route names, version strings, or generic service identifiers need concrete impact before reporting.

## 17. Pre-Auth Rate-Limit Testing

Only test when the control itself is security-relevant, such as:

```text
OTP
password reset
account recovery
login attempts
financial verification
security-sensitive state changes
```

Prefer small, bounded tests. Do not use high-volume abuse that could harm service availability.

## 18. Pre-Auth Chaining

Always ask whether a low-level leak enables a high-impact action:

```text
reset token leak -> ATO
private object read -> password/security mutation
SSRF -> internal credential -> admin action
legacy endpoint -> admin/data access
public object ID -> state-changing IDOR
verification bypass -> protected enrollment/payment
```

Do not chain merely because two findings exist; demonstrate causality.

## 19. Anti-False-Positive Loop

Before reporting, try to explain the response as benign:

```text
Is it public by design?
Is it a decoy/test object?
Is the field intentionally exposed?
Is authorization enforced at a later action?
Is the endpoint a harmless preview?
Is the token non-secret or already public?
Is the apparent bypass limited to UI state?
```

If a benign explanation survives, downgrade to lead or discard.

## 20. Candidate Record

```yaml
surface:
endpoint:
method:
unauthenticated_baseline:
authenticated_control:
protected_resource:
expected_behavior:
observed_behavior:
security_boundary:
exact_request:
exact_response:
impact:
chain:
design_intent:
novelty:
status:
```

## 21. Hard Stop Rules

Stop and discard when:

- the endpoint is intentionally public;
- the exposed data is not sensitive and creates no protected capability;
- the attacker is not actually crossing a security boundary;
- only cosmetic status differs;
- impact is hypothetical;
- testing would require unauthorized third-party data;
- the proof depends on user interaction not established in the program context;
- the issue is out of scope.

## 22. Handoff

Confirmed candidates go to `06-validation-triage-novelty-reporting`.
---
name: authenticated-hunter
description: Deep authenticated vulnerability-hunting skill for authorized bug bounty and pentest work. Uses two-account differential testing, tenant isolation, role boundaries, IDOR/BOLA, mass assignment, session lifecycle, verification, state changes, API consistency, GraphQL, bulk operations, async jobs, business logic, races, and privilege escalation. Curl-first and evidence-driven.
version: 1.0.0
---

# Authenticated Hunter

## Mission

Find security boundary failures that occur after authentication: horizontal access, vertical privilege escalation, cross-tenant isolation failures, state/lifecycle mistakes, mass assignment, business-logic abuse, and inconsistent authorization across product surfaces.

Authentication is not authorization.

The key question is:

> Does the server authorize this actor to perform this operation on this resource in this state?

## 0. Two-Identity Foundation

When program rules permit, establish:

```text
ACCOUNT A = attacker test account
ACCOUNT B = victim test account
```

Prefer different tenants/organizations when the product supports them:

```text
TENANT A / ROLE USER
TENANT B / ROLE USER
```

Add a higher-privilege test identity when allowed:

```text
LOW ROLE
HIGH ROLE
```

Never use another real person's account.

## 1. Authorization Matrix

Build a matrix before changing identifiers:

| Actor | Object A | Object B | Tenant A | Tenant B | Expected |
|---|---|---|---|---|---|
| A | allow | deny | allow | deny | server-enforced |
| B | deny | allow | deny | allow | server-enforced |
| low role | own low-scope | privileged | same tenant | other tenant | least privilege |
| admin test | as documented | as documented | as documented | as documented | policy-defined |

This becomes the expected model.

## 2. Object Inventory

Enumerate business objects:

```text
user
profile
order
invoice
payment
subscription
file
project
workspace
organization
team
invite
API key
audit record
export job
notification
comment
integration
webhook
```

For each, identify:

- owner;
- tenant;
- creator;
- current role;
- lifecycle state;
- share state;
- sensitive operations.

## 3. IDOR / BOLA

Test both read and write operations.

Canonical differential:

```text
A -> A object
A -> B object
B -> B object
```

Potential locations:

```text
path IDs
query IDs
JSON IDs
GraphQL IDs
multipart IDs
bulk arrays
export IDs
file IDs
notification IDs
```

Do not stop after one read endpoint.

Once a read IDOR exists, inspect sibling state-changing operations using the same object class.

## 4. Write / Delete Authorization

Highest-value authorization flaws often affect state changes:

```text
update
create child
invite
role change
refund
withdraw
transfer
delete
restore
API key creation
security-setting change
password/email change
```

Use a safe test object.

Example:

```bash
curl -sS -X PATCH 'https://TARGET/api/objects/OBJ_B' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"safeField":"authorized-test-value"}' \
  -D /tmp/h -o /tmp/b
```

The expected result is a denial; a successful protected mutation is stronger evidence than a readable response alone.

## 5. Cross-Tenant Isolation

Treat tenant ID as a security boundary, not a normal identifier.

Test:

```text
tenant A token + tenant B object
tenant A token + tenant B tenantId
tenant A token + global ID of tenant B
search/export/list with tenant filters
batch APIs containing mixed-tenant objects
```

A strong finding shows that the server returns or mutates data outside the actor's tenant.

## 6. Vertical Privilege Escalation

Map roles and sensitive actions:

```text
user
manager
owner
admin
support
billing
internal
```

For each privileged endpoint ask:

- where is role enforcement?
- is the action hidden only in UI?
- does REST enforce it?
- does GraphQL enforce it?
- does mobile enforce it?
- does batch/export enforce it?

A client-side hidden button is not a privilege escalation.

## 7. Mass Assignment

Look for server binding of untrusted body fields into privileged models.

Potential fields:

```text
role
permissions
ownerId
tenantId
isAdmin
verified
status
subscription
billingPlan
createdBy
```

Do not blindly send destructive privilege fields. Use the minimum mutation needed to establish whether the server accepts an unauthorized security-sensitive property.

Proof requires a real authorization consequence, not merely echoing an extra field.

## 8. Session and Lifecycle Testing

Test authority across time:

```text
before logout
after logout
after password reset
after role downgrade
after removal from organization
after suspension
after token expiry
after API key revocation
after object deletion
```

The critical question:

> Does an old credential retain authority that policy says it should no longer have?

Distinguish stale reads from retained security authority.

## 9. Verification and Security Settings

High-value authenticated targets:

```text
email change
phone change
MFA enrollment/disable
recovery settings
API key generation
OAuth linking
organization ownership transfer
billing changes
security policy changes
```

Verify that the actor has the intended assurance before performing the protected action.

## 10. Cross-Surface Consistency

For each object/action compare:

```text
Web UI request
REST
GraphQL
Mobile
Batch
Import/export
Webhook
Background job
Admin support tool
```

Inconsistency is a hypothesis. Confirm the weaker path actually bypasses the invariant.

## 11. GraphQL Authorization

Test:

- object-level authorization;
- field-level authorization;
- aliases;
- fragments;
- global/node IDs;
- mutations;
- batched requests.

Do not equate introspection with a vulnerability.

## 12. Bulk / Batch Authorization

Batch operations are high-value because developers may validate the collection but not every object.

Test with two test objects:

```text
batch = [A-owned-object, B-owned-object]
```

Expected:

- B object denied;
- A object succeeds if authorized;
- no partial unauthorized side effect.

If the product deliberately supports mixed ownership, follow its policy instead of assuming a flaw.

## 13. Async Jobs / Exports

Map:

```text
create job
 -> job ID
 -> polling endpoint
 -> result download
```

Test whether:

- job IDs are scoped to actor/tenant;
- result endpoints re-check authorization;
- a revoked actor can still fetch a result;
- a different tenant can access a job;
- old export tokens outlive authority.

The final result endpoint needs independent authorization.

## 14. Business Logic in Authenticated Context

Combine this skill with `03-business-logic-hunter` for:

```text
billing
refunds
credits
coupon
subscription
role changes
invitations
resource transfer
ownership
verification
quota
trial
```

The most important distinction:

```text
allowed operation
vs
allowed outcome
```

A valid authenticated request can still create an unauthorized business outcome.

## 15. Race Conditions

Use only test resources.

Look for:

```text
balance check -> deduction
coupon check -> consume
permission check -> action
ownership check -> mutation
invite validation -> acceptance
API key check -> revocation
```

Proof must show an invariant violation with minimal concurrency.

## 16. Chain Analysis

For every authenticated read finding, inspect state-changing siblings:

```text
read -> update
read -> delete
read -> refund
read -> transfer
read -> password/email mutation
read -> role change
```

For every low-priv privilege finding, ask whether it leads to:

```text
admin control
tenant-wide access
ATO
secret extraction
financial impact
```

Only demonstrated chains belong in the final severity story.

## 17. Differential Evidence with curl

Example:

```bash
curl -sS 'https://TARGET/api/object/A' -H 'Cookie: session=COOKIE_A' > A-A.json
curl -sS 'https://TARGET/api/object/B' -H 'Cookie: session=COOKIE_A' > A-B.json
curl -sS 'https://TARGET/api/object/B' -H 'Cookie: session=COOKIE_B' > B-B.json

for f in A-A.json A-B.json B-B.json; do
  echo "=== $f ==="
  jq -S '{id,ownerId,tenantId,role,status,data}' "$f"
done
```

For state-changing operations, capture before/after state for both accounts.

## 18. Falsification Before Escalation

Try to disprove the candidate:

- Is B's object intentionally shareable?
- Is the actor actually granted access through a parent role?
- Is the operation global by design?
- Does a later transaction fail or roll back?
- Is the returned data a public subset?
- Is the apparent role change only client-side?
- Is the resource outside the security boundary being claimed?

## 19. Candidate Record

```yaml
actor:
role:
tenant:
resource:
operation:
expected_authorization:
actual_authorization:
request_a:
response_a:
request_b:
response_b:
state_before:
state_after:
security_boundary:
impact:
chain:
design_intent:
duplicate:
status:
```

## 20. Hard Stops

Discard when:

- attacker already has the same authority;
- resource is intentionally public/shared;
- mutation is global by design;
- effect is cosmetic;
- protected operation ultimately fails;
- impact is hypothetical;
- cross-tenant relationship is not actually security-sensitive;
- same issue is already covered without material additional value.

## 21. Handoff

Confirmed findings go to `06-validation-triage-novelty-reporting`.
---
name: validation-triage-novelty-reporting
description: Final security finding gate for authorized research. Performs strict validation, false-positive rejection, design-intent analysis, duplicate/systemic/regression comparison, evidence sufficiency checks, impact bounding, severity routing, remediation-oriented root-cause analysis, and final triager-grade reporting. No candidate becomes a report until every mandatory gate passes.
version: 1.0.0
---

# Validation, Triage, Novelty & Final Reporting

## Mission

This skill is the final gate.

The objective is to prevent:

- false positives;
- informative/N/A reports;
- duplicates;
- unsupported severity;
- speculative chains;
- undocumented assumptions;
- non-reproducible reports;
- out-of-scope submissions.

A high-quality report is not merely a real bug. It is a real, in-scope, reproducible, impactful, novel-or-materially-additive security finding with evidence that a triager can independently validate.

## Final State Machine

```text
LEAD
  -> FALSIFY
  -> VERIFY
  -> IMPACT
  -> DESIGN INTENT
  -> NOVELTY / DUPLICATE
  -> SCOPE
  -> REPRODUCIBILITY
  -> SEVERITY
  -> REPORT
```

Any failed gate changes the state:

```text
FALSE POSITIVE - DISCARD
INFORMATIVE / NO IMPACT
NOT APPLICABLE / OUT OF SCOPE
DUPLICATE / SYSTEMIC COVERAGE
UNPROVEN - RETURN TO HUNT
VALID - REPORT
VALID - CHAINED REPORT
```

## 1. Scope Gate

Confirm:

```text
program
asset
endpoint/feature
account/object
authorization to test
```

If any layer is uncertain, do not report until clarified through the authorized program context.

## 2. Exact-Reproduction Gate

A finding must have:

- exact method;
- exact URL/path/query;
- required headers;
- required cookies/token context;
- exact body;
- relevant ordering of requests;
- response status/body evidence;
- expected vs actual behavior.

Preferred evidence:

```text
raw HTTP request
raw HTTP response headers
raw response body
before/after state
control case
```

If the issue cannot be reproduced from the available evidence, keep it unproven.

## 3. Server-Side Ground Truth

Rank evidence:

```text
1. server-side state change / protected data returned
2. server-side authorization decision bypassed
3. controlled callback proving server-side action
4. reliable HTTP response differential
5. source code/static evidence
6. client-only observation
```

Client-only behavior cannot carry a report unless it produces a server-side security consequence.

## 4. Impact Gate: Capability Then Consequence

Require:

```text
Observation
 -> capability
 -> unauthorized capability
 -> security boundary crossing
 -> concrete impact
```

Examples:

```text
200 response -> protected PII -> unauthorized actor -> privacy breach
accepted URL -> server callback -> internal response -> protected data
extra role field -> server accepts role -> privilege changes -> admin access
replayed request -> duplicate transaction -> business rule violated -> financial effect
```

A theoretical “could lead to RCE” is not RCE proof.

## 5. Design-Intent Gate

Ask:

- Is behavior documented?
- Is the resource intentionally public/shared?
- Does the user already have this capability?
- Is another security control intentionally responsible for it?
- Is the endpoint a preview/metadata operation rather than the protected action?
- Is the observed data deliberately client-visible?
- Is the product's permission model broader than assumed?

Do not confuse “unexpected” with “vulnerable.”

## 6. Falsification Loop

For each candidate, write the strongest benign explanation.

Then attempt to prove that explanation wrong.

Example:

```text
Claim: unauthenticated user can read private object.
Benign hypothesis: object is intentionally public.
Test: verify documentation, public UX, anonymous sharing semantics, and owner-specific controls.
```

Only when the benign explanation is disproved should the candidate move forward.

## 7. False-Positive Reduction

Common false positives:

| Signal | Why not enough |
|---|---|
| HTTP 200 | may be public or a harmless wrapper |
| stack trace | disclosure without concrete effect |
| source map | source visibility without security consequence |
| public API key | may be intentionally public/client-scoped |
| internal hostname | may reveal no protected capability |
| CORS | no credentialed sensitive read demonstrated |
| CSRF token absence | no working cross-site state change demonstrated |
| client-side role check | server may enforce role correctly |
| SQL error | error alone does not prove exploitable injection |
| URL parameter | parser acceptance does not prove SSRF |
| random ID access | object may be public or intended to be shareable |
| race suspicion | concurrency without invariant violation |

## 8. “Could the Attacker Already Do This?” Test

Before reporting:

```text
Does the attacker already have the returned data?
Can they already perform the action through another legitimate endpoint?
Is the object shared with them?
Does their role already include the capability?
Is the result intended for all users?
```

If yes, no security boundary may have been crossed.

## 9. Duplicate / Novelty Matrix

Compare each candidate against historical or known reports using:

| Dimension | Question |
|---|---|
| target | same component? |
| resource | same business object? |
| endpoint | same/equivalent implementation path? |
| parameter | same vulnerable input? |
| root cause | same underlying flaw? |
| primitive | same exploitation method? |
| trust boundary | same boundary? |
| role | same actor relationship? |
| workflow | same business flow? |
| state | same invalid transition? |
| capability | same unauthorized capability? |
| impact | same consequence? |
| remediation | same underlying fix? |
| timing | same historical issue? |
| evidence | genuinely new evidence? |

### Strong novelty signals

- distinct affected component;
- distinct authorization mechanism;
- distinct workflow/state machine;
- distinct trust boundary;
- materially broader demonstrated impact;
- genuinely different exploitation primitive;
- new root-cause insight;
- evidence of a regression after a previous fix.

### Weak novelty signals

- different parameter name only;
- different object ID only;
- same bug on a sibling endpoint using the same root cause;
- same impact with a different payload;
- cosmetic path difference;
- separate reproduction of an established systemic issue without additional value.

## 10. Systemic Issue Analysis

If multiple endpoints share the same root cause, do not automatically submit each endpoint as independent.

Ask:

```text
same middleware?
same authorization function?
same ORM scope?
same trust boundary?
same remediation?
same business capability?
```

A distinct component or materially new impact can justify separate value.

## 11. Regression vs Duplicate

A resurfaced issue may be a regression rather than a duplicate.

Validate:

```text
was the prior issue resolved?
what was the historical fix?
is current behavior materially the same?
did the vulnerability return after remediation?
is the affected code path different?
```

Do not label a new regression as duplicate solely because the category is the same.

## 12. Evidence Coverage Matrix

Every final claim must map to evidence:

| Claim | Evidence |
|---|---|
| endpoint exists | request/response |
| auth state | credential context |
| resource belongs to victim test account | setup state |
| attacker should be denied | authorization model/control request |
| bypass works | raw server response |
| mutation occurred | before/after state |
| impact | measurable consequence |
| scale | number/type of test objects |
| chain | evidence for every link |
| novelty | historical comparison |

If a claim has no evidence, remove or qualify it.

## 13. Chain Validation

For a chained report, require:

```text
Entry point proven
AND
Link 2 proven
AND
Link 3 proven
...
AND
Final impact proven
```

Do not report a chain as fact when one link is only hypothetical.

When a link cannot be safely demonstrated, report only the proven primitive and state the boundary of evidence.

## 14. Severity Discipline

Severity must follow demonstrated impact and exploit conditions.

Evaluate:

```text
confidentiality
integrity
availability
privilege required
user interaction
attack complexity
scope
business criticality
repeatability
scale actually demonstrated
```

Do not upgrade because a finding “looks scary.” High and Critical are both evidence-defined severe outcomes; do not artificially rank one above the other during hunting. Context, demonstrated impact, exploitability, and program policy determine the final level.

If a dedicated CVSS scorer/risk assessor is available, pass the validated finding to it only after evidence is complete.

## 15. Informative / N-A Rejection Gate

Reject as a report when the only value is:

- best-practice deviation;
- EOL version without exploitable effect;
- stack trace without meaningful impact;
- public source map without concrete consequence;
- public identifier;
- missing security header without exploit;
- CORS without credentialed sensitive-data access;
- CSRF theory without executable state-changing proof;
- rate-limit absence with no sensitive endpoint impact;
- public/intentional data exposure;
- scanner output without manual validation.

## 16. Report Structure

Use one coherent security story.

```text
TITLE
SEVERITY
ASSET / ENDPOINT
SUMMARY
PRECONDITIONS
STEPS TO REPRODUCE
RAW REQUESTS / RESPONSES
EXPECTED BEHAVIOR
ACTUAL BEHAVIOR
SECURITY BOUNDARY VIOLATION
IMPACT
CHAIN (only if proven)
SCOPE / COVERAGE
ROOT CAUSE
REMEDIATION
REFERENCES (optional)
```

### Title formula

```text
[Bug Class] on [endpoint/feature] allows [specific unauthorized capability]
```

Examples:

```text
BOLA on invoice endpoint allows cross-tenant invoice modification
Unauthenticated recovery-token reuse allows account takeover
Payment workflow race allows duplicate credit issuance
SSRF in document import allows server-side access to protected internal resources
```

Avoid vague titles such as “Critical vulnerability in API.”

## 17. Reproduction Standards

Steps must be copy-paste friendly.

For curl-first agents:

```bash
curl -i -X METHOD 'https://TARGET/PATH' \
  -H 'Authorization: Bearer REDACTED' \
  -H 'Content-Type: application/json' \
  --data '{"testObjectId":"OBJ"}'
```

Include the request context, not only the payload.

## 18. Root-Cause-First Explanation

Explain the underlying reason:

```text
missing object scoping
inconsistent authorization middleware
stale privilege cache
client-derived monetary total trusted server-side
verification state not bound to account
missing replay/idempotency enforcement
```

Do not stop at:

```text
change id=1 to id=2
```

Explain why the server accepted the unauthorized operation.

## 19. Remediation Reasoning

Suggest the narrowest robust fix:

```text
enforce authorization at the server-side object lookup
bind verification evidence to user/object/transaction
recompute authoritative totals server-side
make state transition atomic
invalidate authority on role/revocation changes
enforce the same policy on every alternate surface
bind job/export result to actor/tenant
```

If several findings obviously share one root cause, flag systemic remediation explicitly.

## 20. False Positive Repair Loop

A rejected hypothesis is not wasted work. Treat it as an analysis defect to learn from.

When a candidate is classified as `FALSE POSITIVE - DISCARD`:

1. Record the exact false-positive mechanism.
2. Identify which assumption was wrong.
3. Record the server-side control or design rule that disproved it.
4. Update the hunt notes so the same false positive is not revisited.
5. Identify adjacent surfaces where the same assumption may still fail.
6. Form a new, narrower hypothesis.
7. Re-run the minimum evidence sequence on the neighboring surface.

Example:

```text
False positive: endpoint returned PII
Reason: PII was intentionally public profile data
Learning: public profile model was broader than assumed
Next hunt: private account fields / cross-tenant mutation endpoint
```

This loop prevents the agent from merely deleting noise; it converts invalid hypotheses into better research.

## 21. Final Decision Checklist

```text
[ ] In scope
[ ] Authorized test context
[ ] Intended behavior understood
[ ] Security invariant written
[ ] Exact request available
[ ] Exact response available
[ ] Server-side proof
[ ] Unauthorized capability demonstrated
[ ] Concrete impact demonstrated
[ ] Chain links independently proven
[ ] Benign explanations disproved
[ ] Historical comparison completed
[ ] Duplicate/systemic risk assessed
[ ] Regression possibility assessed
[ ] Coverage accurately stated
[ ] Severity justified
[ ] Report reproducible by stranger
[ ] Credentials/secrets sanitized
[ ] Remediation grounded in root cause
```

Only when all required validation gates pass may the candidate enter final-report state. “100% validated” means 100% of the required evidence gates are satisfied; it does not mean metaphysical certainty beyond the tested scope.

```text
FINAL DECISION = VALID - REPORT
```

## 22. Candidate Ledger

```yaml
candidate_id:
program:
asset:
feature:
status:
scope:
mode:
actor:
resource:
security_invariant:
request_sequence:
server_evidence:
impact:
chain:
design_intent:
falsification:
duplicate_risk:
systemic_risk:
regression_status:
novelty:
severity:
coverage:
root_cause:
remediation:
final_decision:
```

## 23. Final Reporting Principle

A report should make a skilled triager think:

```text
I understand the bug.
I understand why it violates the security model.
I can reproduce it from the evidence.
I can see the impact.
I can distinguish it from prior reports.
I know what should be fixed.
```

That is the completion condition.
