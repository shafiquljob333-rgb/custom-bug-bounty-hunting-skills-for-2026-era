---
name: unauthenticated-hunter
description: Deep pre-authentication hunting skill for authorized targets. Maps everything reachable without credentials and tests authentication boundaries, public/private exposure, IDOR-like access, SSRF, injection, RCE candidates, verification bypasses, account recovery, OAuth/SSO, legacy endpoints, upload/import flows, and other pre-auth surfaces with curl-first proof and strict false-positive controls.
version: 1.0.0
---

# Unauthenticated Hunter

## Mission

Find real security-boundary failures that allow a pre-authenticated attacker to obtain capabilities, data, or state transitions reserved for authenticated or otherwise trusted actors.

The question is never:

> “Can I reach this endpoint without a cookie?”

The question is:

> “What protected capability or protected data does the unauthenticated actor gain, and is that outside the intended public design?”

## 0. Pre-Auth Surface Map

Enumerate:

```text
login
registration
password reset
account recovery
email verification
phone verification
OAuth / SSO initiation and callback
invite acceptance
public search
public object sharing
public APIs
file access
file upload/import
webhooks
URL fetchers
PDF/rendering
GraphQL
legacy APIs
health/debug/admin surfaces
mobile API routes
```

Build a table:

| Surface | Expected auth | Actual auth | Protected object/capability | Candidate |
|---|---|---|---|---|

## 1. Baseline Without Credentials

For each endpoint:

```bash
curl -sS -D /tmp/h -o /tmp/b 'https://TARGET/PATH'
printf 'status=%s bytes=%s type=%s\n' \
  "$(awk 'toupper($1) ~ /^HTTP/ {code=$2} END{print code}' /tmp/h)" \
  "$(wc -c </tmp/b)" \
  "$(grep -i '^content-type:' /tmp/h | tail -1)"
```

Compare against an authenticated request when a test account exists.

## 2. Public vs Private vs Internal

Do not classify by appearance.

For any unauthenticated response, establish:

1. Is this intentionally public?
2. Is it documented?
3. Does it expose only a public representation?
4. Does it contain user-private data?
5. Does it expose credentials or security tokens?
6. Does it unlock another protected action?
7. Is the resource accessible through ordinary product UX?
8. Is the response already delivered to anonymous users by design?

A route returning 200 is not a vulnerability.

## 3. Authentication Boundary Differential

Compare:

```text
Unauth -> protected object
Auth A -> A's object
Auth A -> B's object
```

When the product has public resources, also use:

```text
Unauth -> public object
Unauth -> private object
```

A strong finding demonstrates that private behavior is indistinguishable from or incorrectly granted to pre-auth callers.

## 4. Unauthenticated IDOR / Object-Level Authorization

Search for object references in:

```text
path IDs
query IDs
JSON IDs
GraphQL IDs
export IDs
share tokens
file IDs
order IDs
invoice IDs
user IDs
organization IDs
```

Test only test objects and identifiers legitimately available to the tester.

Example:

```bash
curl -sS 'https://TARGET/api/profile/TEST_PRIVATE_OBJECT' \
  -D unauth.headers -o unauth.body
```

If the object should be private, compare it with the owner's authenticated response.

Do not assume randomness makes an IDOR impossible. The important question is whether a reliable identifier acquisition path exists and whether server-side authorization is missing.

## 5. Legacy / Versioned Auth Bypass

Compare:

```text
/api/v1/
/api/v2/
/api/
/mobile/
/graphql
/rest
legacy routes
```

Look for inconsistent authentication middleware or object-level checks.

Do not report version differences unless the unauthenticated or low-privileged path actually reaches a protected capability.

## 6. Authentication and Session Boundary Testing

High-value areas:

- session creation;
- token exchange;
- password reset;
- account recovery;
- email/phone verification;
- OAuth callbacks;
- magic links;
- invite acceptance.

Test whether a pre-auth state can be upgraded to a privileged state without satisfying the intended proof.

## 7. Recovery / Reset Flows

Model:

```text
request recovery
 -> proof / token
 -> verification
 -> credential change
 -> authenticated session
```

Hypotheses:

- token not bound to intended account;
- token accepted after expiration/reuse;
- protected step skipped;
- reset endpoint fails to enforce recovery proof;
- recovery changes sensitive identity state without sufficient assurance.

Use only test accounts.

## 8. Verification Gate Bypass

Test:

```text
email verification
phone verification
MFA preconditions
KYC / identity proof
device trust
invite acceptance
admin approval
payment verification
```

For each:

```text
precondition
 -> evidence
 -> server enforcement
 -> protected action
```

A valid finding requires the protected action to succeed without the required gate.

## 9. SSRF Pre-Auth Surface

Prioritize features that accept URLs:

```text
import from URL
fetch URL
webhook tester
image/PDF fetcher
URL preview
link unfurling
remote file upload
feed importer
callback verifier
```

Proof hierarchy:

```text
URL parser accepts arbitrary URL
 < server makes outbound request
 < controlled callback proves server-side request
 < response reveals protected internal content
```

Use only a controlled callback endpoint or approved collaborator service.

Do not broadly scan internal address ranges or cloud metadata without explicit authorization.

## 10. Pre-Auth SSRF Chaining

Potential chain:

```text
unauthenticated URL fetch
 -> internal service reachable
 -> sensitive response returned
 -> credential/token acquired
 -> protected capability
```

Every link must be demonstrated or clearly bounded.

## 11. SQL / NoSQL Injection Pre-Auth

Map input surfaces:

```text
search
filter
sort
login
username
email
IDs
pagination
GraphQL variables
JSON query objects
```

Use the safest sequence:

```text
baseline
 -> harmless syntax probe
 -> response/error differential
 -> boolean differential
 -> timing if justified
```

An error alone does not prove injection.

## 12. RCE Candidates Pre-Auth

Prioritize server-side execution surfaces:

```text
template rendering
file processing
archive extraction
image/PDF conversion
command wrappers
code evaluation
plugin/config loaders
deserialization
```

Require an actual server-side effect. A string appearing in an error is not RCE.

Do not deploy persistent shells or destructive payloads in production bounty environments.

## 13. File Upload / Import

Map:

```text
upload endpoint
metadata
filename
content type
storage path
preview/transformer
asynchronous processing
public retrieval
```

Security questions:

- can an unauthenticated user upload?
- is the uploaded file executed or interpreted?
- can it escape intended storage?
- can the server process attacker-controlled content dangerously?
- does the result become public?

Use harmless test files.

## 14. OAuth / SSO Pre-Auth

Map:

```text
authorize
callback
token exchange
redirect_uri
state
nonce
linking
login initiation
```

Test the security invariants:

```text
redirect target is bound to client
state is bound to session/flow
nonce is validated where applicable
callback belongs to the intended transaction
account linking requires the right identity proof
```

A redirect parameter reflecting attacker input is not automatically a vulnerability; demonstrate token/code or account-boundary impact.

## 15. Public API / GraphQL

For GraphQL, map operations and object access.

Compare the same object through:

```text
REST endpoint
GraphQL query
node/global ID
batch endpoint
export endpoint
```

A GraphQL introspection result alone is usually attack-surface intelligence. Report only demonstrated security consequences.

## 16. Information Disclosure

High-value pre-auth disclosures include:

- credentials;
- active session material;
- reset tokens;
- private user data;
- cross-tenant data;
- private object content;
- internal data that directly unlocks a protected capability.

Low-value observations such as public keys, route names, version strings, or generic service identifiers need concrete impact before reporting.

## 17. Pre-Auth Rate-Limit Testing

Only test when the control itself is security-relevant, such as:

```text
OTP
password reset
account recovery
login attempts
financial verification
security-sensitive state changes
```

Prefer small, bounded tests. Do not use high-volume abuse that could harm service availability.

## 18. Pre-Auth Chaining

Always ask whether a low-level leak enables a high-impact action:

```text
reset token leak -> ATO
private object read -> password/security mutation
SSRF -> internal credential -> admin action
legacy endpoint -> admin/data access
public object ID -> state-changing IDOR
verification bypass -> protected enrollment/payment
```

Do not chain merely because two findings exist; demonstrate causality.

## 19. Anti-False-Positive Loop

Before reporting, try to explain the response as benign:

```text
Is it public by design?
Is it a decoy/test object?
Is the field intentionally exposed?
Is authorization enforced at a later action?
Is the endpoint a harmless preview?
Is the token non-secret or already public?
Is the apparent bypass limited to UI state?
```

If a benign explanation survives, downgrade to lead or discard.

## 20. Candidate Record

```yaml
surface:
endpoint:
method:
unauthenticated_baseline:
authenticated_control:
protected_resource:
expected_behavior:
observed_behavior:
security_boundary:
exact_request:
exact_response:
impact:
chain:
design_intent:
novelty:
status:
```

## 21. Hard Stop Rules

Stop and discard when:

- the endpoint is intentionally public;
- the exposed data is not sensitive and creates no protected capability;
- the attacker is not actually crossing a security boundary;
- only cosmetic status differs;
- impact is hypothetical;
- testing would require unauthorized third-party data;
- the proof depends on user interaction not established in the program context;
- the issue is out of scope.

## 22. Handoff

Confirmed candidates go to `06-validation-triage-novelty-reporting`.
