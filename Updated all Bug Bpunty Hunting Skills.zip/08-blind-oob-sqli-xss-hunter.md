---
name: blind-oob-sqli-xss-hunter
description: Blind and out-of-band SQLi/XSS research skill with second-order analysis, deterministic baselines and anti-false-positive proof gates.
version: 2026.08
---

# Blind SQLi + Blind XSS Hunter

## Mission
Prove a server-side or browser-side execution path when the result is not immediately reflected. Blind means “not directly visible,” not “guess until something looks interesting.”

## Authorization + Safety
Use only authorized targets and attacker-controlled callbacks. Never use blind probes that can destroy data, exhaust production resources, or exfiltrate real secrets.

## Blind SQLi Taxonomy
- boolean-based blind
- time-based blind
- DNS/OOB SQLi
- second-order SQLi
- stored-data SQLi triggered by an admin/worker
- API/GraphQL blind injection
- ORM/query-builder injection
- NoSQL blind injection where supported by the application design

## Blind SQLi Validation Ladder
1. Establish a stable baseline over multiple requests.
2. Create a TRUE/FALSE pair that should differ only when the predicate is evaluated.
3. For timing, compare distributions rather than one slow request.
4. Eliminate rate limiting, network jitter, CDN variance and application caching as explanations.
5. Escalate to OOB only when explicitly permitted and when it reduces ambiguity.
6. Prove the security impact with the smallest non-sensitive datum possible.

### Timing Rules
- Collect multiple baseline samples.
- Collect multiple true-condition samples.
- Collect multiple false-condition samples.
- Compare median and spread.
- A single outlier is never proof.

## Blind XSS Taxonomy
- stored blind XSS in admin/moderation dashboards
- blind XSS in support/ticketing systems
- blind XSS in analytics/event viewers
- blind XSS in asynchronous processing pipelines
- blind XSS in email-rendering or preview interfaces
- second-order XSS where stored data reaches a privileged browser context

## Blind XSS Callback Design
Use a unique, non-destructive callback marker for each sink. The callback must establish:
- unique identifier
- exact trigger time
- triggering path if available
- relevant origin/context metadata

Do not attempt credential theft or destructive browser actions. The proof goal is script execution in the security-relevant context.

## Server/Browser Context Attribution
A callback alone is insufficient if an unrelated system could trigger it. Correlate:
- unique payload
- exact submission time
- record ID
- worker/admin path
- callback headers or source information
- repeatability

## Second-Order Method
```text
INPUT
  ↓
STORAGE / TRANSFORMATION
  ↓
LATER CONSUMER
  ↓
SENSITIVE CONTEXT
  ↓
OBSERVABLE EFFECT
```
Trace every stage. Document where the input changes representation.

## Curl-First Observation
```bash
curl -sk -D resp.hdr -o resp.body \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode 'field=UNIQUE-CANARY' \
  'https://TARGET.example/submit'
```
Use external tooling only for the callback receiver and correlation; keep the application evidence in raw HTTP form.

## False-Positive Filters
Reject:
- browser-only local execution with no attacker-controlled persistence
- callback from a scanner/security crawler not tied to privileged context
- timing differences that disappear under repeated sampling
- generic 500 errors without semantic correlation
- payload stored but never executed

## Impact Escalation
Blind XSS becomes high-value only when execution occurs in a privileged context and a realistic security boundary is crossed. Blind SQLi must demonstrate query evaluation and then a meaningful security impact, not merely an anomaly.
