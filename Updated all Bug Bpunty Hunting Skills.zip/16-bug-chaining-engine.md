---
name: bug-chaining-engine
description: Deep exploit-chain reasoning skill that combines individually modest primitives into one reproducible impact chain while avoiding speculative chaining.
version: 2026.08
---

# Bug Chaining Engine

## Mission
Treat every confirmed weakness as a possible connector. The goal is not to inflate severity; it is to prove a real sequence of dependencies that produces greater impact.

## Chain Graph
For every finding create:
```text
ENTRY → PREREQUISITE → CONNECTOR → PRIVILEGE/CAPABILITY → IMPACT
```

For each edge store the exact evidence that makes the transition possible.

## Common Chain Families
- IDOR read → identifier discovery → IDOR write → ATO/financial abuse
- SSRF → internal service → privileged action/credential → escalation
- OAuth redirect weakness → code exposure → token exchange → ATO
- subdomain takeover → OAuth/cookie/CSP trust → session or script control
- cache poisoning/deception → secret/session exposure → ATO
- blind XSS → privileged browser execution → account/admin action
- race → repeated token/entitlement/financial state → impact
- request smuggling → cache/routing/auth confusion → multi-user impact
- info disclosure → secret/API key → privileged API operation

## Chain Validation Rule
Never join two bugs merely because they are theoretically compatible. Prove:
- first-stage output exists
- second-stage input accepts it
- dependency is within attacker control
- final impact occurs

## Chain Minimization
Prefer the shortest reproducible path. Remove unnecessary steps and speculative assumptions.

## Reporting
Report the chain as one coherent attack story when the stages are dependent and materially increase impact. Preserve individual primitives only when the program requires separate findings or they have independent value.
