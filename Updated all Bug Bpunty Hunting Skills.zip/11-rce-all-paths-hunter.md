---
name: rce-all-paths-hunter
description: High-severity RCE research skill covering command, template, deserialization, file-processing, expression, plugin and SSRF-chain execution paths with safe canary proof.
version: 2026.08
---

# RCE — All Paths Hunter

## Mission
Identify only reproducible server-side code/command execution where attacker-controlled input reaches an execution sink. Prove execution with a harmless, uniquely attributable canary.

## Execution Surface Taxonomy
- OS command injection
- template injection / SSTI
- expression-language injection
- unsafe deserialization
- server-side script evaluation
- file upload → executable interpretation
- archive extraction / path traversal → execution chain
- image/document parser exploitation
- plugin/module loading
- CI/CD or automation execution
- dynamic code generation
- database-to-command chains
- SSRF → internal service → execution
- authentication bypass → privileged execution sink

## Source-to-Sink Model
```text
ATTACKER INPUT
  ↓
PARSER / NORMALIZER
  ↓
STORAGE / TRANSFORM
  ↓
EXECUTION SINK
  ↓
CANARY OBSERVATION
```

Trace every transformation.

## Evidence Standard
Prefer deterministic, non-destructive markers such as:
- unique output string
- controlled file creation in an authorized temp location
- controlled callback from a command execution context
- benign environment property read

Do not destroy data, alter persistence, or establish remote shells during validation.

## RCE False Positives
Reject:
- client-side JavaScript execution
- template rendering without server-side execution
- generic 500 errors
- command-looking strings reflected in output
- a library CVE with no demonstrated reachability
- sandbox escapes claimed without proving the sandbox boundary

## Impact Chain
Once RCE is proven, map the minimum real impact:
- process identity
- accessible secrets
- application data
- adjacent services
- cloud identity
- tenant boundary
- persistence opportunities

Only report escalation that is actually demonstrated or directly evidenced by authorized local inspection.
