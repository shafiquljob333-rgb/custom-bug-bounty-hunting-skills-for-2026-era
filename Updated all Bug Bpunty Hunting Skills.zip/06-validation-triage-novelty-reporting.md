---
name: validation-triage-novelty-reporting
description: Final security finding gate for authorized research. Performs strict validation, false-positive rejection, design-intent analysis, duplicate/systemic/regression comparison, evidence sufficiency checks, impact bounding, severity routing, remediation-oriented root-cause analysis, and final triager-grade reporting. No candidate becomes a report until every mandatory gate passes.
version: 1.0.0
---

# Validation, Triage, Novelty & Final Reporting

## Mission

This skill is the final gate.

The objective is to prevent:

- false positives;
- informative/N/A reports;
- duplicates;
- unsupported severity;
- speculative chains;
- undocumented assumptions;
- non-reproducible reports;
- out-of-scope submissions.

A high-quality report is not merely a real bug. It is a real, in-scope, reproducible, impactful, novel-or-materially-additive security finding with evidence that a triager can independently validate.

## Final State Machine

```text
LEAD
  -> FALSIFY
  -> VERIFY
  -> IMPACT
  -> DESIGN INTENT
  -> NOVELTY / DUPLICATE
  -> SCOPE
  -> REPRODUCIBILITY
  -> SEVERITY
  -> REPORT
```

Any failed gate changes the state:

```text
FALSE POSITIVE - DISCARD
INFORMATIVE / NO IMPACT
NOT APPLICABLE / OUT OF SCOPE
DUPLICATE / SYSTEMIC COVERAGE
UNPROVEN - RETURN TO HUNT
VALID - REPORT
VALID - CHAINED REPORT
```

## 1. Scope Gate

Confirm:

```text
program
asset
endpoint/feature
account/object
authorization to test
```

If any layer is uncertain, do not report until clarified through the authorized program context.

## 2. Exact-Reproduction Gate

A finding must have:

- exact method;
- exact URL/path/query;
- required headers;
- required cookies/token context;
- exact body;
- relevant ordering of requests;
- response status/body evidence;
- expected vs actual behavior.

Preferred evidence:

```text
raw HTTP request
raw HTTP response headers
raw response body
before/after state
control case
```

If the issue cannot be reproduced from the available evidence, keep it unproven.

## 3. Server-Side Ground Truth

Rank evidence:

```text
1. server-side state change / protected data returned
2. server-side authorization decision bypassed
3. controlled callback proving server-side action
4. reliable HTTP response differential
5. source code/static evidence
6. client-only observation
```

Client-only behavior cannot carry a report unless it produces a server-side security consequence.

## 4. Impact Gate: Capability Then Consequence

Require:

```text
Observation
 -> capability
 -> unauthorized capability
 -> security boundary crossing
 -> concrete impact
```

Examples:

```text
200 response -> protected PII -> unauthorized actor -> privacy breach
accepted URL -> server callback -> internal response -> protected data
extra role field -> server accepts role -> privilege changes -> admin access
replayed request -> duplicate transaction -> business rule violated -> financial effect
```

A theoretical “could lead to RCE” is not RCE proof.

## 5. Design-Intent Gate

Ask:

- Is behavior documented?
- Is the resource intentionally public/shared?
- Does the user already have this capability?
- Is another security control intentionally responsible for it?
- Is the endpoint a preview/metadata operation rather than the protected action?
- Is the observed data deliberately client-visible?
- Is the product's permission model broader than assumed?

Do not confuse “unexpected” with “vulnerable.”

## 6. Falsification Loop

For each candidate, write the strongest benign explanation.

Then attempt to prove that explanation wrong.

Example:

```text
Claim: unauthenticated user can read private object.
Benign hypothesis: object is intentionally public.
Test: verify documentation, public UX, anonymous sharing semantics, and owner-specific controls.
```

Only when the benign explanation is disproved should the candidate move forward.

## 7. False-Positive Reduction

Common false positives:

| Signal | Why not enough |
|---|---|
| HTTP 200 | may be public or a harmless wrapper |
| stack trace | disclosure without concrete effect |
| source map | source visibility without security consequence |
| public API key | may be intentionally public/client-scoped |
| internal hostname | may reveal no protected capability |
| CORS | no credentialed sensitive read demonstrated |
| CSRF token absence | no working cross-site state change demonstrated |
| client-side role check | server may enforce role correctly |
| SQL error | error alone does not prove exploitable injection |
| URL parameter | parser acceptance does not prove SSRF |
| random ID access | object may be public or intended to be shareable |
| race suspicion | concurrency without invariant violation |

## 8. “Could the Attacker Already Do This?” Test

Before reporting:

```text
Does the attacker already have the returned data?
Can they already perform the action through another legitimate endpoint?
Is the object shared with them?
Does their role already include the capability?
Is the result intended for all users?
```

If yes, no security boundary may have been crossed.

## 9. Duplicate / Novelty Matrix

Compare each candidate against historical or known reports using:

| Dimension | Question |
|---|---|
| target | same component? |
| resource | same business object? |
| endpoint | same/equivalent implementation path? |
| parameter | same vulnerable input? |
| root cause | same underlying flaw? |
| primitive | same exploitation method? |
| trust boundary | same boundary? |
| role | same actor relationship? |
| workflow | same business flow? |
| state | same invalid transition? |
| capability | same unauthorized capability? |
| impact | same consequence? |
| remediation | same underlying fix? |
| timing | same historical issue? |
| evidence | genuinely new evidence? |

### Strong novelty signals

- distinct affected component;
- distinct authorization mechanism;
- distinct workflow/state machine;
- distinct trust boundary;
- materially broader demonstrated impact;
- genuinely different exploitation primitive;
- new root-cause insight;
- evidence of a regression after a previous fix.

### Weak novelty signals

- different parameter name only;
- different object ID only;
- same bug on a sibling endpoint using the same root cause;
- same impact with a different payload;
- cosmetic path difference;
- separate reproduction of an established systemic issue without additional value.

## 10. Systemic Issue Analysis

If multiple endpoints share the same root cause, do not automatically submit each endpoint as independent.

Ask:

```text
same middleware?
same authorization function?
same ORM scope?
same trust boundary?
same remediation?
same business capability?
```

A distinct component or materially new impact can justify separate value.

## 11. Regression vs Duplicate

A resurfaced issue may be a regression rather than a duplicate.

Validate:

```text
was the prior issue resolved?
what was the historical fix?
is current behavior materially the same?
did the vulnerability return after remediation?
is the affected code path different?
```

Do not label a new regression as duplicate solely because the category is the same.

## 12. Evidence Coverage Matrix

Every final claim must map to evidence:

| Claim | Evidence |
|---|---|
| endpoint exists | request/response |
| auth state | credential context |
| resource belongs to victim test account | setup state |
| attacker should be denied | authorization model/control request |
| bypass works | raw server response |
| mutation occurred | before/after state |
| impact | measurable consequence |
| scale | number/type of test objects |
| chain | evidence for every link |
| novelty | historical comparison |

If a claim has no evidence, remove or qualify it.

## 13. Chain Validation

For a chained report, require:

```text
Entry point proven
AND
Link 2 proven
AND
Link 3 proven
...
AND
Final impact proven
```

Do not report a chain as fact when one link is only hypothetical.

When a link cannot be safely demonstrated, report only the proven primitive and state the boundary of evidence.

## 14. Severity Discipline

Severity must follow demonstrated impact and exploit conditions.

Evaluate:

```text
confidentiality
integrity
availability
privilege required
user interaction
attack complexity
scope
business criticality
repeatability
scale actually demonstrated
```

Do not upgrade because a finding “looks scary.” High and Critical are both evidence-defined severe outcomes; do not artificially rank one above the other during hunting. Context, demonstrated impact, exploitability, and program policy determine the final level.

If a dedicated CVSS scorer/risk assessor is available, pass the validated finding to it only after evidence is complete.

## 15. Informative / N-A Rejection Gate

Reject as a report when the only value is:

- best-practice deviation;
- EOL version without exploitable effect;
- stack trace without meaningful impact;
- public source map without concrete consequence;
- public identifier;
- missing security header without exploit;
- CORS without credentialed sensitive-data access;
- CSRF theory without executable state-changing proof;
- rate-limit absence with no sensitive endpoint impact;
- public/intentional data exposure;
- scanner output without manual validation.

## 16. Report Structure

Use one coherent security story.

```text
TITLE
SEVERITY
ASSET / ENDPOINT
SUMMARY
PRECONDITIONS
STEPS TO REPRODUCE
RAW REQUESTS / RESPONSES
EXPECTED BEHAVIOR
ACTUAL BEHAVIOR
SECURITY BOUNDARY VIOLATION
IMPACT
CHAIN (only if proven)
SCOPE / COVERAGE
ROOT CAUSE
REMEDIATION
REFERENCES (optional)
```

### Title formula

```text
[Bug Class] on [endpoint/feature] allows [specific unauthorized capability]
```

Examples:

```text
BOLA on invoice endpoint allows cross-tenant invoice modification
Unauthenticated recovery-token reuse allows account takeover
Payment workflow race allows duplicate credit issuance
SSRF in document import allows server-side access to protected internal resources
```

Avoid vague titles such as “Critical vulnerability in API.”

## 17. Reproduction Standards

Steps must be copy-paste friendly.

For curl-first agents:

```bash
curl -i -X METHOD 'https://TARGET/PATH' \
  -H 'Authorization: Bearer REDACTED' \
  -H 'Content-Type: application/json' \
  --data '{"testObjectId":"OBJ"}'
```

Include the request context, not only the payload.

## 18. Root-Cause-First Explanation

Explain the underlying reason:

```text
missing object scoping
inconsistent authorization middleware
stale privilege cache
client-derived monetary total trusted server-side
verification state not bound to account
missing replay/idempotency enforcement
```

Do not stop at:

```text
change id=1 to id=2
```

Explain why the server accepted the unauthorized operation.

## 19. Remediation Reasoning

Suggest the narrowest robust fix:

```text
enforce authorization at the server-side object lookup
bind verification evidence to user/object/transaction
recompute authoritative totals server-side
make state transition atomic
invalidate authority on role/revocation changes
enforce the same policy on every alternate surface
bind job/export result to actor/tenant
```

If several findings obviously share one root cause, flag systemic remediation explicitly.

## 20. False Positive Repair Loop

A rejected hypothesis is not wasted work. Treat it as an analysis defect to learn from.

When a candidate is classified as `FALSE POSITIVE - DISCARD`:

1. Record the exact false-positive mechanism.
2. Identify which assumption was wrong.
3. Record the server-side control or design rule that disproved it.
4. Update the hunt notes so the same false positive is not revisited.
5. Identify adjacent surfaces where the same assumption may still fail.
6. Form a new, narrower hypothesis.
7. Re-run the minimum evidence sequence on the neighboring surface.

Example:

```text
False positive: endpoint returned PII
Reason: PII was intentionally public profile data
Learning: public profile model was broader than assumed
Next hunt: private account fields / cross-tenant mutation endpoint
```

This loop prevents the agent from merely deleting noise; it converts invalid hypotheses into better research.

## 21. Final Decision Checklist

```text
[ ] In scope
[ ] Authorized test context
[ ] Intended behavior understood
[ ] Security invariant written
[ ] Exact request available
[ ] Exact response available
[ ] Server-side proof
[ ] Unauthorized capability demonstrated
[ ] Concrete impact demonstrated
[ ] Chain links independently proven
[ ] Benign explanations disproved
[ ] Historical comparison completed
[ ] Duplicate/systemic risk assessed
[ ] Regression possibility assessed
[ ] Coverage accurately stated
[ ] Severity justified
[ ] Report reproducible by stranger
[ ] Credentials/secrets sanitized
[ ] Remediation grounded in root cause
```

Only when all required validation gates pass may the candidate enter final-report state. “100% validated” means 100% of the required evidence gates are satisfied; it does not mean metaphysical certainty beyond the tested scope.

```text
FINAL DECISION = VALID - REPORT
```

## 22. Candidate Ledger

```yaml
candidate_id:
program:
asset:
feature:
status:
scope:
mode:
actor:
resource:
security_invariant:
request_sequence:
server_evidence:
impact:
chain:
design_intent:
falsification:
duplicate_risk:
systemic_risk:
regression_status:
novelty:
severity:
coverage:
root_cause:
remediation:
final_decision:
```

## 23. Final Reporting Principle

A report should make a skilled triager think:

```text
I understand the bug.
I understand why it violates the security model.
I can reproduce it from the evidence.
I can see the impact.
I can distinguish it from prior reports.
I know what should be fixed.
```

That is the completion condition.
