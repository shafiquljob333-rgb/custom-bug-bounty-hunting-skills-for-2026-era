---
name: authenticated-hunter
description: Deep authenticated vulnerability-hunting skill for authorized bug bounty and pentest work. Uses two-account differential testing, tenant isolation, role boundaries, IDOR/BOLA, mass assignment, session lifecycle, verification, state changes, API consistency, GraphQL, bulk operations, async jobs, business logic, races, and privilege escalation. Curl-first and evidence-driven.
version: 1.0.0
---

# Authenticated Hunter

## Mission

Find security boundary failures that occur after authentication: horizontal access, vertical privilege escalation, cross-tenant isolation failures, state/lifecycle mistakes, mass assignment, business-logic abuse, and inconsistent authorization across product surfaces.

Authentication is not authorization.

The key question is:

> Does the server authorize this actor to perform this operation on this resource in this state?

## 0. Two-Identity Foundation

When program rules permit, establish:

```text
ACCOUNT A = attacker test account
ACCOUNT B = victim test account
```

Prefer different tenants/organizations when the product supports them:

```text
TENANT A / ROLE USER
TENANT B / ROLE USER
```

Add a higher-privilege test identity when allowed:

```text
LOW ROLE
HIGH ROLE
```

Never use another real person's account.

## 1. Authorization Matrix

Build a matrix before changing identifiers:

| Actor | Object A | Object B | Tenant A | Tenant B | Expected |
|---|---|---|---|---|---|
| A | allow | deny | allow | deny | server-enforced |
| B | deny | allow | deny | allow | server-enforced |
| low role | own low-scope | privileged | same tenant | other tenant | least privilege |
| admin test | as documented | as documented | as documented | as documented | policy-defined |

This becomes the expected model.

## 2. Object Inventory

Enumerate business objects:

```text
user
profile
order
invoice
payment
subscription
file
project
workspace
organization
team
invite
API key
audit record
export job
notification
comment
integration
webhook
```

For each, identify:

- owner;
- tenant;
- creator;
- current role;
- lifecycle state;
- share state;
- sensitive operations.

## 3. IDOR / BOLA

Test both read and write operations.

Canonical differential:

```text
A -> A object
A -> B object
B -> B object
```

Potential locations:

```text
path IDs
query IDs
JSON IDs
GraphQL IDs
multipart IDs
bulk arrays
export IDs
file IDs
notification IDs
```

Do not stop after one read endpoint.

Once a read IDOR exists, inspect sibling state-changing operations using the same object class.

## 4. Write / Delete Authorization

Highest-value authorization flaws often affect state changes:

```text
update
create child
invite
role change
refund
withdraw
transfer
delete
restore
API key creation
security-setting change
password/email change
```

Use a safe test object.

Example:

```bash
curl -sS -X PATCH 'https://TARGET/api/objects/OBJ_B' \
  -H 'Cookie: session=COOKIE_A' \
  -H 'Content-Type: application/json' \
  --data '{"safeField":"authorized-test-value"}' \
  -D /tmp/h -o /tmp/b
```

The expected result is a denial; a successful protected mutation is stronger evidence than a readable response alone.

## 5. Cross-Tenant Isolation

Treat tenant ID as a security boundary, not a normal identifier.

Test:

```text
tenant A token + tenant B object
tenant A token + tenant B tenantId
tenant A token + global ID of tenant B
search/export/list with tenant filters
batch APIs containing mixed-tenant objects
```

A strong finding shows that the server returns or mutates data outside the actor's tenant.

## 6. Vertical Privilege Escalation

Map roles and sensitive actions:

```text
user
manager
owner
admin
support
billing
internal
```

For each privileged endpoint ask:

- where is role enforcement?
- is the action hidden only in UI?
- does REST enforce it?
- does GraphQL enforce it?
- does mobile enforce it?
- does batch/export enforce it?

A client-side hidden button is not a privilege escalation.

## 7. Mass Assignment

Look for server binding of untrusted body fields into privileged models.

Potential fields:

```text
role
permissions
ownerId
tenantId
isAdmin
verified
status
subscription
billingPlan
createdBy
```

Do not blindly send destructive privilege fields. Use the minimum mutation needed to establish whether the server accepts an unauthorized security-sensitive property.

Proof requires a real authorization consequence, not merely echoing an extra field.

## 8. Session and Lifecycle Testing

Test authority across time:

```text
before logout
after logout
after password reset
after role downgrade
after removal from organization
after suspension
after token expiry
after API key revocation
after object deletion
```

The critical question:

> Does an old credential retain authority that policy says it should no longer have?

Distinguish stale reads from retained security authority.

## 9. Verification and Security Settings

High-value authenticated targets:

```text
email change
phone change
MFA enrollment/disable
recovery settings
API key generation
OAuth linking
organization ownership transfer
billing changes
security policy changes
```

Verify that the actor has the intended assurance before performing the protected action.

## 10. Cross-Surface Consistency

For each object/action compare:

```text
Web UI request
REST
GraphQL
Mobile
Batch
Import/export
Webhook
Background job
Admin support tool
```

Inconsistency is a hypothesis. Confirm the weaker path actually bypasses the invariant.

## 11. GraphQL Authorization

Test:

- object-level authorization;
- field-level authorization;
- aliases;
- fragments;
- global/node IDs;
- mutations;
- batched requests.

Do not equate introspection with a vulnerability.

## 12. Bulk / Batch Authorization

Batch operations are high-value because developers may validate the collection but not every object.

Test with two test objects:

```text
batch = [A-owned-object, B-owned-object]
```

Expected:

- B object denied;
- A object succeeds if authorized;
- no partial unauthorized side effect.

If the product deliberately supports mixed ownership, follow its policy instead of assuming a flaw.

## 13. Async Jobs / Exports

Map:

```text
create job
 -> job ID
 -> polling endpoint
 -> result download
```

Test whether:

- job IDs are scoped to actor/tenant;
- result endpoints re-check authorization;
- a revoked actor can still fetch a result;
- a different tenant can access a job;
- old export tokens outlive authority.

The final result endpoint needs independent authorization.

## 14. Business Logic in Authenticated Context

Combine this skill with `03-business-logic-hunter` for:

```text
billing
refunds
credits
coupon
subscription
role changes
invitations
resource transfer
ownership
verification
quota
trial
```

The most important distinction:

```text
allowed operation
vs
allowed outcome
```

A valid authenticated request can still create an unauthorized business outcome.

## 15. Race Conditions

Use only test resources.

Look for:

```text
balance check -> deduction
coupon check -> consume
permission check -> action
ownership check -> mutation
invite validation -> acceptance
API key check -> revocation
```

Proof must show an invariant violation with minimal concurrency.

## 16. Chain Analysis

For every authenticated read finding, inspect state-changing siblings:

```text
read -> update
read -> delete
read -> refund
read -> transfer
read -> password/email mutation
read -> role change
```

For every low-priv privilege finding, ask whether it leads to:

```text
admin control
tenant-wide access
ATO
secret extraction
financial impact
```

Only demonstrated chains belong in the final severity story.

## 17. Differential Evidence with curl

Example:

```bash
curl -sS 'https://TARGET/api/object/A' -H 'Cookie: session=COOKIE_A' > A-A.json
curl -sS 'https://TARGET/api/object/B' -H 'Cookie: session=COOKIE_A' > A-B.json
curl -sS 'https://TARGET/api/object/B' -H 'Cookie: session=COOKIE_B' > B-B.json

for f in A-A.json A-B.json B-B.json; do
  echo "=== $f ==="
  jq -S '{id,ownerId,tenantId,role,status,data}' "$f"
done
```

For state-changing operations, capture before/after state for both accounts.

## 18. Falsification Before Escalation

Try to disprove the candidate:

- Is B's object intentionally shareable?
- Is the actor actually granted access through a parent role?
- Is the operation global by design?
- Does a later transaction fail or roll back?
- Is the returned data a public subset?
- Is the apparent role change only client-side?
- Is the resource outside the security boundary being claimed?

## 19. Candidate Record

```yaml
actor:
role:
tenant:
resource:
operation:
expected_authorization:
actual_authorization:
request_a:
response_a:
request_b:
response_b:
state_before:
state_after:
security_boundary:
impact:
chain:
design_intent:
duplicate:
status:
```

## 20. Hard Stops

Discard when:

- attacker already has the same authority;
- resource is intentionally public/shared;
- mutation is global by design;
- effect is cosmetic;
- protected operation ultimately fails;
- impact is hypothetical;
- cross-tenant relationship is not actually security-sensitive;
- same issue is already covered without material additional value.

## 21. Handoff

Confirmed findings go to `06-validation-triage-novelty-reporting`.
