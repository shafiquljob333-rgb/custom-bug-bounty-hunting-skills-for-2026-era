---
name: cache-deception-poisoning
description: Cache-key and cache-behavior research skill covering web cache poisoning, web cache deception, normalization gaps, multi-user impact and cache-assisted attack chains.
version: 2026.08
---

# Cache Deception & Cache Poisoning Hunter

## Mission
Prove that attacker-controlled content or authenticated sensitive content is stored and later served under a cache policy that creates a security boundary violation.

## Model
```text
REQUEST → EDGE/CACHE KEY → ORIGIN → RESPONSE → CACHE STORE → OTHER CLIENT
```

Map every layer's keying and normalization behavior.

## Attack Classes
- reflected input cached for other users
- unkeyed header poisoning
- path/query normalization mismatch
- cache deception of authenticated content
- extension/static-path heuristics
- parameter pollution against cache/origin disagreement
- method normalization differences
- host/forwarded-host cache poisoning
- cache-assisted redirect or response-header poisoning
- smuggling-assisted cache poisoning

## Validation Gate
For poisoning, demonstrate:
1. attacker request changes cache state
2. cache stores the poisoned representation
3. separate client receives it
4. security-relevant harm occurs

For deception, demonstrate:
1. authenticated/private response is cached
2. cache key makes it retrievable by an unauthorized party
3. second client can retrieve it without the victim's authentication

## False Positives
Do not report:
- only your own browser seeing the modified response
- a cache header anomaly without cross-user effect
- a response that is never cached
- content that is intentionally public

## High-Impact Targets
Prioritize authentication pages, account data, JavaScript assets, multi-tenant pages, reset/recovery responses and CDN-shared resources.
