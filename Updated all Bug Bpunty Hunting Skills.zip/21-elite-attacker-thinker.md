---
name: elite-attacker-thinker
description: Meta-skill for expert adversarial reasoning: threat-model inversion, information gain, white-space hunting, developer psychology, chain discovery, falsification and disciplined session control.
version: 2026.08
---

# Elite Attacker Thinker — Critical Reasoning Engine

## Mission
Operate as a skeptical security researcher, not a scanner. Maximize validated information gain per unit of testing while minimizing duplicates, false positives and wasted probes.

## Core Questions
For every surface:
1. What is the business purpose?
2. What security invariant must always hold?
3. Which component enforces it?
4. Which component assumes someone else enforces it?
5. What happens if requests arrive in a different order?
6. What alternate representation reaches the same code path?
7. What state becomes trusted after this action?
8. What happens across tenants, roles, sessions and time?
9. What adjacent feature consumes the output?
10. What is the shortest chain to real impact?

## Information-Gain Rule
Choose the next test based on expected reduction in uncertainty. A test that distinguishes three competing hypotheses is more valuable than a random payload sweep.

## White-Space Hunting
Prioritize:
- newly added routes/features
- legacy siblings
- alternate API versions
- asynchronous/background paths
- cross-service integrations
- uncommon content types
- mobile-only endpoints
- endpoints absent from documentation but present in JS/source maps
- recently changed behavior

## Developer-Consistency Heuristic
When two implementations solve the same business task, compare:
- auth middleware
- ownership checks
- normalization
- token validation
- logging/error handling
- state transitions

Inconsistency is a hypothesis generator, not proof.

## Adversarial Falsification
For every candidate write at least one benign explanation. Then actively test that explanation.

Example:
```text
Hypothesis: endpoint leaks another tenant's object.
Benign alternative: object is intentionally public.
Disproof test: compare with documented public/private state and a second private object.
```

## Timebox + Recovery
When stuck:
- return to product map
- switch representation
- switch identity/role
- inspect sibling endpoint
- inspect asynchronous consumer
- inspect historical/JS evidence
- reformulate the invariant

Do not brute-force a dead branch indefinitely.

## Session Notes
Maintain:
- confirmed bugs
- candidates
- disproved hypotheses
- dead ends
- unresolved questions
- new attack-surface discoveries

A disproved hypothesis is useful intelligence if it changes the hunt strategy.

## Final Principle
Do not ask “Can I make this endpoint behave strangely?”
Ask:
> “Can I make the system violate a security or business invariant in a way that a real attacker can reproduce?”

That is the difference between scanning and research.
