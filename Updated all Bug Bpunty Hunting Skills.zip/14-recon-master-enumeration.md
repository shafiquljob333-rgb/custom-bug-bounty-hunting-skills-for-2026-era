---
name: recon-master-enumeration
description: Deep reconnaissance and attack-surface mapping skill covering subdomains, dead/broken hosts, IPs, endpoints, JS, links, sensitive files, parameter discovery, historical URLs, technologies and hidden assets.
version: 2026.08
---

# Recon Master — Deep Enumeration

## Mission
Maximize attack-surface understanding, not request count. Produce a normalized asset graph and an attack queue.

## Phase A — Scope/Seed Inventory
- root domains and wildcard scope
- known hostnames
- certificate names
- documented API domains
- mobile/API endpoints
- third-party integrations within scope

## Phase B — Subdomain Discovery
Use multiple independent sources where authorized:
- certificate transparency
- passive DNS
- historical URLs
- public code references
- search engines
- DNS wordlists
- resolver-based brute force
- permutation/alteration generation
- takeover/provider fingerprinting

Classify every hostname as:
- live web service
- non-HTTP service
- DNS-only
- parked
- dead/broken/delegation anomaly
- takeover candidate
- unresolved but historically meaningful

## Important: “Not Alive” Is Not “Not Interesting”
A dead/broken hostname can still reveal:
- CNAME targets
- provider fingerprints
- forgotten environments
- stale OAuth allowlists
- cookie scope risk
- takeover candidates
- historical endpoints

Never drop an asset solely because HTTP probing failed.

## Phase C — DNS/IP Mapping
Record:
- A/AAAA
- CNAME chains
- NS/MX/TXT where relevant
- historical IPs
- shared hosting/CDN evidence
- ASN/netblock context where permitted

Do not scan unrelated neighbors merely because the IP is shared.

## Phase D — HTTP Surface
Probe reachable hosts for:
- HTTP/HTTPS
- redirects
- status classes
- titles
- technologies
- server headers
- cookies
- API indicators
- authentication boundaries

## Phase E — URL/Endpoint Discovery
Combine:
- live crawling
- JS extraction
- robots.txt / sitemap.xml
- OpenAPI/GraphQL documentation
- historical archives
- public source repositories
- mobile/API references

Classify endpoints by function:
`auth`, `account`, `admin`, `billing`, `upload`, `export`, `import`, `search`, `webhook`, `callback`, `integration`, `internal`, `debug`, `file`, `share`.

## Phase F — JS Intelligence
For every in-scope JS bundle:
- extract URLs/routes
- API prefixes
- hidden params
- feature flags
- environment labels
- source maps
- auth logic
- client-side authorization assumptions
- third-party hosts
- secrets/tokens only as evidence, never as permission to use outside scope

## Phase G — Sensitive Files / Metadata
Check only appropriate, authorized paths and robots-known references:
- configuration exposure
- source maps
- backups
- debug artifacts
- API schemas
- changelogs/build metadata
- logs where intentionally exposed

“Sensitive-looking” does not equal sensitive. Validate actual security relevance.

## Phase H — Parameter Discovery
Find parameters in:
- query strings
- forms
- JSON
- GraphQL variables
- path segments
- headers
- cookies
- multipart metadata
- hidden client state

Track parameter name, type, endpoint, auth context, and candidate vuln classes.

## Google/Search Dorking
Use search engines to discover indexed attack-surface evidence, not to access unrelated private information. Prioritize exact program scope terms, file types and endpoint vocabulary derived from the target.

## Recon Output
Produce:
1. asset inventory
2. live/dead/unknown host table
3. DNS/IP map
4. endpoint catalog
5. JS catalog
6. parameter catalog
7. sensitive-surface queue
8. high-severity hypothesis queue
9. historical/new/changed surface comparison
