---
name: waf-bypass-any-bug-class
description: Methodical WAF-differential skill for discovering whether an edge filter can be bypassed to reach a confirmed backend vulnerability, with emphasis on normalization and origin behavior rather than payload spam.
version: 2026.08
---

# WAF Bypass — Any Bug Class

## Mission
A WAF bypass is not a finding by itself. The objective is to prove that an edge control can be bypassed and that the bypass reaches a real, impact-bearing backend security flaw.

## Workflow
1. Baseline allowed request.
2. Confirm blocked request.
3. Identify what security decision the WAF is trying to make.
4. Map transformations between client, WAF and origin.
5. Change one representation feature at a time.
6. Compare WAF decision and origin behavior.
7. Validate the backend vulnerability independently.

## Differential Dimensions
- case/encoding normalization
- path canonicalization
- duplicate parameters
- content-type handling
- parameter location (query/path/header/body)
- multipart boundaries
- alternative JSON/XML representations
- HTTP/2 vs HTTP/1.1 normalization
- duplicate/ambiguous headers
- proxy-added headers
- method override behavior
- chunking/framing differentials

## Rules
Never treat a 200 response after a WAF block as proof of bypass. Confirm the exact backend security boundary is crossed.

## Bug-Specific Examples
- WAF bypass → SQLi only if query evaluation is proven.
- WAF bypass → XSS only if execution is proven.
- WAF bypass → traversal only if unauthorized file access is proven.
- WAF bypass → RCE only if server execution is proven.
- WAF bypass → request smuggling only if parser desync is proven.

## Evidence Matrix
```text
WAF blocked baseline      = yes
Transformation changed    = yes
WAF allowed variant       = yes
Origin received payload   = proven
Backend vuln               = proven
Impact                     = proven
```
Any missing row means “candidate,” not “finding.”
